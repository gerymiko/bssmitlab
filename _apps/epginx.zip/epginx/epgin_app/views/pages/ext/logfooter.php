	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/epgin/login/vendor/animsition/js/animsition.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/epgin/login/vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/epgin/bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/jquery-validation/dist/jquery.validate.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/alphanum/jquery.alphanum.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/toastr/toastr.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/epgin/login/vendor/select2/select2.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/epgin/login/js/main.js"></script>