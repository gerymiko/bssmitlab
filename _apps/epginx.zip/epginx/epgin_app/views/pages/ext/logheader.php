	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/epgin/bootstrap/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/global/font-awesome/css/all.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/epgin/login/fonts/iconic/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/epgin/login/vendor/animate/animate.css">	
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/epgin/login/vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/epgin/login/vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/global/toastr/toastr.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/epgin/login/vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/epgin/login/css/main.css">
	<?php if(count($css_script) !== 0){ for ($i=0; $i < count($css_script); $i++) { echo $css_script[$i];}}?>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/jquery/jquery-3.4.1.min.js"></script>