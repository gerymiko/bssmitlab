<link rel="stylesheet" href="<?=siteURL()?>bssmitlab/_assets/mosento/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?=siteURL()?>bssmitlab/_assets/mosento/datatables_bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/mosento/datatables_bs/css/responsive.dataTables.min.css">
<link rel="stylesheet" href="<?=siteURL()?>bssmitlab/_assets/mosento/dist-mosento/css/AdminLTE.min.css">
<link rel="stylesheet" href="<?=siteURL()?>bssmitlab/_assets/mosento/dist-mosento/css/skins/skin-blue.min.css">
<link rel="stylesheet" href="<?=siteURL()?>bssmitlab/_assets/mosento/dist-mosento/css/custom.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/global/sweetalert/sweetalert2.min.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/mosento/daterangepicker/daterangepicker.min.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<link rel="stylesheet" href="<?=siteURL()?>bssmitlab/_assets/mosento/font-awesome/css/all.min.css" />
<!-- <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script> -->
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/jquery/dist/jquery.min.js"></script>
