<div class="container">
   <div class="navbar-header">
         <img src="<?=site_url();?>syslink/logo" alt="BSS MOSENTO" class="logo" />
         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
            <i class="fa fa-bars"></i>
         </button>
   </div>
   <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
      <ul class="nav navbar-nav">
         <li class=""><a href="<?=site_url();?>cpanel/syspanel">Home</a></li>
         <li><a href="<?=site_url();?>cunit/sysunit">Unit</a></li>
         <li><a href="<?=site_url();?>cmaster/sysmaster">Master</a></li>
         <li><a href="<?=site_url();?>cprivilege/sysprivilege">Privilege</a></li>
      </ul>
   </div>
   <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">
         <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
               <i class="fas fa-bell"></i>
               <span class="label label-warning">10</span>
            </a>
            <ul class="dropdown-menu">
               <li class="header">You have 10 notifications</li>
               <li>
                  <ul class="menu">
                     <li>
                        <a href="#">
                           <i class="fa fa-users text-aqua"></i> 5 new members joined today
                        </a>
                     </li>
                  </ul>
               </li>
               <li class="footer"><a href="#">View all</a></li>
            </ul>
         </li>
         <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
               <img src="<?=site_url();?>syslink/icon_user" class="user-image" alt="user">
               <span class="hidden-xs"><?=$this->session->userdata('nik');?></span>
            </a>
            <ul class="dropdown-menu">
               <li class="user-header">
                  <p>
                     <?=$this->session->userdata('nik')?>
                     <small><?=$this->session->userdata('nama')?></small>
                  </p>
               </li>
               <li class="user-footer">
                  <div class="pull-left">
                     <a href="#" class="btn btn-default btn-flat">Profile</a>
                  </div>
                  <div class="pull-right">
                     <a href="<?=site_url();?>cpanel/syspanel/logout" class="btn btn-danger btn-flat">Sign out</a>
                  </div>
               </li>
            </ul>
         </li>
      </ul>
   </div>
</div>