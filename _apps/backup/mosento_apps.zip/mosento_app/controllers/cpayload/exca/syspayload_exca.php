<?php defined('BASEPATH') OR exit('No direct script access allowed');

    class Syspayload_exca extends CI_Controller{

        function __construct(){
            parent::__construct();
            if ($this->session->userdata('nik') == null || $this->session->userdata('tipeapp') != 'MOSENTO') {
                redirect('syslogin');
            }
            $this->load->model(['mpayload/exca/mod_payload_exca']);
        }

        private static function pregReps($string){ 
            $result = preg_replace('/[^a-zA-Z0-9- _.,]/','', $string);
            return $result;
        }

        private static function pregRepn($number){ 
            $result = preg_replace('/[^0-9]/','', $number);
            return $result;
        }

        public function unit($sn){
            $sn = $this->encrypt->decode($sn);
        	$data = array(
                'header'  => 'pages/ext/header',
                'footer'  => 'pages/ext/footer',
                'menu'    => 'pages/ptopbar/vtopbar',
                'content' => 'pages/ppayload/exca/vpayload_exca',
                'detail_exca' => $this->mod_payload_exca->get_detail_exca($sn),
                'site_unit'   => $this->mod_payload_exca->get_unit_exca($sn)
        	);
        	$this->load->view('pages/pindex/index', $data);
        }

    }
?>