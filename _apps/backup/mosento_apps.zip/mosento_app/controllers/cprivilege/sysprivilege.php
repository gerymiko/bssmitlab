<?php defined('BASEPATH') OR exit('No direct script access allowed');

    class Sysprivilege extends CI_Controller{

        function __construct(){
            parent::__construct();
            if ($this->session->userdata('nik') == null || $this->session->userdata('tipeapp') != 'MOSENTO') {
                redirect('syslogin');
            }
            $this->load->model(['mprivilege/mod_privilege']);
        }

        private static function pregReps($string){ 
            $result = preg_replace('/[^a-zA-Z0-9- _.,]/','', $string);
            return $result;
        }

        private static function pregRepn($number){ 
            $result = preg_replace('/[^0-9]/','', $number);
            return $result;
        }

        public function index(){
            $data = array(
                'header'  => 'pages/ext/header',
                'footer'  => 'pages/ext/footer',
                'menu'    => 'pages/ptopbar/vtopbar',
                'content' => 'pages/pprivilege/vprivilege'
            );
            $this->load->view('pages/pindex/index', $data);
        }

        public function table_privilege(){
            $privilege = $this->mod_privilege->get_privilege();
            $data      = array();
            $no        = $this->pregRepn($this->input->post('start'));

            foreach ($privilege as $field){
                $no++;
                $row               = array();
                $row['no']         = $no;
                $row['nik']        = $field->nik;
                $row['nama']       = $field->nama;
                $row['email']      = $field->email;
                $row['type']       = $field->level_name;
                $row['username']   = $field->username;
                $row['last_login'] = $field->last_login;
                $row['action']     = '<button class="btn btn-xs btn-danger" data-toggle="modal" data-target="#modal-edit-privilege">Edit</button>';
                $data[]            = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_privilege->count_all_privilege(),
                "recordsFiltered" => $this->mod_privilege->count_filtered_privilege(),
                "data"            => $data,
            );
            echo json_encode($output);
        }

    }
?>