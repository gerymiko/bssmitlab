<?php defined('BASEPATH') OR exit('No direct script access allowed');

	class Mod_privilege extends CI_Model {

		var $col_order_priv  = array(null, 'a.nik', 'a.nama', );
		var $col_search_priv = array('a.nik', 'a.nama',); 
		var $order_priv      = array('a.id_level' => 'ASC');

		function __construct() {
	        parent::__construct();
	        $this->load->database();
	    }

	    private static function pregReps($string) { 
	        $result = preg_replace('/[^a-zA-Z0-9 _.]/','', $string);
	        return $result;
	    }

	    private static function pregRepn($number) { 
	        $result = preg_replace('/[^0-9]/','', $number);
	        return $result;
	    }

	    private function _get_privilege(){
	    	$this->db->select('b.level_name, a.nik, a.nama, a.email, a.phone, a.jabatan, a.kodest, a.username, a.last_login, a.status');
	        $this->db->from('mos_user a');
	        $this->db->join('mos_user_level b', 'a.id_level = b.id_level', 'inner');
	        $this->db->join('HRD.dbo.TKaryawan c', 'a.nik = c.NIK', 'inner');
	 
	        $i = 0;
	     
	        foreach ($this->col_search_priv as $item){
	            if($this->pregReps($_POST['search']['value'])){
	                if($i===0){
	                    $this->db->group_start(); 
	                    $this->db->like($item, $this->pregReps($_POST['search']['value']));
	                } else {
	                    $this->db->or_like($item, $this->pregReps($_POST['search']['value']));
	                }
	                if(count($this->col_search_priv) - 1 == $i) $this->db->group_end(); 
	            }
	            $i++;
	        }

	        if(isset($_POST['order'])){
				$this->db->order_by($this->pregReps($this->col_order_priv[$_POST['order']['0']['column']]), $this->pregReps($_POST['order']['0']['dir']));
			} else if(isset($this->order_priv)){
				$order = $this->order_priv;
				$this->db->order_by(key($order), $order[key($order)]);
			}
	    }

	    function get_privilege(){
	        $this->_get_privilege();
	        if($this->pregReps($_POST['length']) != -1)
	        $this->db->limit($this->pregReps($_POST['length']), $this->pregReps($_POST['start']));
	        $query = $this->db->get();
	        return $query->result();
	    }

	    function count_filtered_privilege(){
	        $this->_get_privilege();
	        $query = $this->db->get();
	        return $query->num_rows();
	    }

	    function count_all_privilege(){
	    	$this->db->select('a.id_level, a.nik, a.nama, a.email, a.phone, a.jabatan, a.kodest, a.username, a.last_login, a.status');
	    	$this->db->from('mos_user a');
	        $this->db->join('mos_user_level b', 'a.id_level = b.id_level', 'inner');
	        $this->db->join('HRD.dbo.TKaryawan c', 'a.nik = c.NIK', 'inner');
	        return $this->db->count_all_results();
	    }

	}
?>