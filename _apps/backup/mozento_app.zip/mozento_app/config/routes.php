<?php defined('BASEPATH') OR exit('No direct script access allowed');

	// LOGIN
	$route['login']        = 'syslogin/index';
	$route['authenticate'] = 'syslogin/auth_login';

	// LOGOUT
	$route['logout'] = 'cpanel/syspanel/logout';
	
	// SCRIPT FILE LINK
	$route['s_url/(:any)'] = 'syslink/$1';
	
	// DASHBOARD
	$route['dashboard'] = 'cpanel/syspanel';
	
	// UNIT
	$route['unit']      = 'cunit/sysunit';
	$route['data/unit'] = 'cunit/sysunit/table_unit';
	
	// MASTER
	$route['master'] = 'cmaster/sysmaster';
	
	// PRIVILEGE
	$route['privilege']             = 'cprivilege/sysprivilege';
	$route['privilege/t_privilege'] = 'cprivilege/sysprivilege/table_privilege';
	$route['privilege/getDataEm']   = 'cprivilege/sysprivilege/getKaryawan';
	$route['privilege/checkData']   = 'cprivilege/sysprivilege/check_user';
	$route['privilege/s_addUser']   = 'cprivilege/sysprivilege/save_add_user';
	$route['privilege/s_editUser']  = 'cprivilege/sysprivilege/save_edit_user';
	
	// CRITICAL
	$route['report/critical'] = 'ccritical/syscritical';
	$route['data/critical']   = 'ccritical/syscritical/table_critical_unit';
	
	// CAUTION
	$route['report/caution'] = 'ccaution/syscaution';
	$route['data/caution']   = 'ccaution/syscaution/table_caution_unit';
	
	// FAULT
	$route['report/fault'] = 'cfault/sysfault';
	$route['data/fault']   = 'cfault/sysfault/table_fault_unit';

	// WARNING UNIT
	$route['warning/unit/exca/(:any)'] = 'cdetail/exca/sysdetail_exca/unit/$1';
	$route['warning/unit/hd/(:any)']   = 'cdetail/hd/sysdetail_hd/unit/$1';

	// WARNING UNIT HD TABLE
	$route['t_warning/unit/hd/(:any)']      = 'cdetail/hd/sysdetail_hd/table_warning_unit/$1';
	$route['t_oil/unit/hd/(:any)']          = 'cdetail/hd/sysdetail_hd/table_engine_oil_temperature/$1';
	$route['t_fuel/unit/hd/(:any)']         = 'cdetail/hd/sysdetail_hd/table_fuel_rate/$1';
	$route['t_transmission/unit/hd/(:any)'] = 'cdetail/hd/sysdetail_hd/table_transmission_oil_temperature/$1';
	$route['t_coolant/unit/hd/(:any)']      = 'cdetail/hd/sysdetail_hd/table_engine_coolant_temperature/$1';
	$route['t_blow/unit/hd/(:any)']         = 'cdetail/hd/sysdetail_hd/table_blow_by_pressure/$1';
	$route['t_boost/unit/hd/(:any)']        = 'cdetail/hd/sysdetail_hd/table_boost_pressure/$1';
	$route['t_travel/unit/hd/(:any)']       = 'cdetail/hd/sysdetail_hd/table_travel_speed/$1';
	$route['t_engine/unit/hd/(:any)']       = 'cdetail/hd/sysdetail_hd/table_engine_speed/$1';
	$route['t_front/unit/hd/(:any)']        = 'cdetail/hd/sysdetail_hd/table_front_brake/$1';
	$route['t_rear/unit/hd/(:any)']         = 'cdetail/hd/sysdetail_hd/table_rear_brake/$1';

	// WARNING UNIT HD CHART
	$route['chart_oil/unit/hd/(:any)']          = 'cdetail/hd/sysdetail_hd/chart_engine_oil_temperature/$1';
	$route['chart_fuel/unit/hd/(:any)']         = 'cdetail/hd/sysdetail_hd/chart_fuel_rate/$1';
	$route['chart_transmission/unit/hd/(:any)'] = 'cdetail/hd/sysdetail_hd/chart_transmission_oil_temperature/$1';
	$route['chart_coolant/unit/hd/(:any)']      = 'cdetail/hd/sysdetail_hd/chart_engine_coolant_temperature/$1';
	$route['chart_blow/unit/hd/(:any)']         = 'cdetail/hd/sysdetail_hd/chart_blow_by_pressure/$1';
	$route['chart_boost/unit/hd/(:any)']        = 'cdetail/hd/sysdetail_hd/chart_boost_pressure/$1';
	$route['chart_travel/unit/hd/(:any)']       = 'cdetail/hd/sysdetail_hd/chart_travel_speed/$1';
	$route['chart_engine/unit/hd/(:any)']       = 'cdetail/hd/sysdetail_hd/chart_engine_speed/$1';
	$route['chart_front/unit/hd/(:any)']        = 'cdetail/hd/sysdetail_hd/chart_front_brake/$1';
	$route['chart_rear/unit/hd/(:any)']         = 'cdetail/hd/sysdetail_hd/chart_rear_brake/$1';

	// WARNING UNIT HD INFO
	$route['info_payload/unit/hd/(:any)']         = 'cpayload/hd/syspayload_hd/info_payload/$1';


	// PAYLOAD
	$route['payload/unit/hd/(:any)'] = 'cpayload/hd/syspayload_hd/unit/$1';

	$route['default_controller']   = 'syslogin';
	$route['404_override']         = '';
	$route['translate_uri_dashes'] = FALSE;

?>
