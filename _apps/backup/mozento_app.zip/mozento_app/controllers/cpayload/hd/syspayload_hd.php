<?php defined('BASEPATH') OR exit('No direct script access allowed');

    class Syspayload_hd extends CI_Controller{

        function __construct(){
            parent::__construct();
            if ($this->session->userdata('nik') == null || $this->session->userdata('tipeapp') != 'MOSENTO') {
                redirect('login');
            }
            $this->load->model(['mpayload/hd/mod_payload_hd']);
        }

        private static function pregReps($string){ 
            $result = preg_replace('/[^a-zA-Z0-9- _.,]/','', $string);
            return $result;
        }

        private static function pregRepn($number){ 
            $result = preg_replace('/[^0-9]/','', $number);
            return $result;
        }

        private static function dateValid($number){ 
            $result = preg_replace('/[^0-9-]/','', $number);
            return $result;
        }

        public function array_fungsi($array, $rumus1, $rumus2 = null){
            $aa = array();
            foreach ($array as $key) {
                if ($rumus2 != null) {
                    $a = floatval($key['payload'] / $rumus1 / $rumus2);
                } else {
                    $a = floatval($key['payload'] / $rumus1);
                }
                $aa[] = $a;
            }
            return $aa;
        }

        public function unit($sn){
            $sn = $this->my_encryption->decode($sn);
        	$data = array(
                'header'    => 'pages/ext/header',
                'footer'    => 'pages/ext/footer',
                'menu'      => 'pages/ptopbar/vtopbar',
                'content'   => 'pages/ppayload/hd/vpayload_hd',
                'detail_hd' => $this->mod_payload_hd->get_detail_hd($sn),
                'site_unit' => $this->mod_payload_hd->get_unit_hd($sn)
        	);
        	$this->load->view('pages/pindex/index', $data);
        }

        public function info_payload($sn){
            $sn = $this->my_encryption->decode($sn);
            $all_payload = $this->mod_payload_hd->get_all_payload($sn);

            $payloadValue = $this->array_fungsi($all_payload, 10);
            $payloadBCM   = $this->array_fungsi($all_payload, 10, 2.47);
            if (empty($payloadValue)) { $averagePay = 0;
            } else { $averagePay = array_sum($payloadValue) / count($payloadValue); }
            if (empty($payloadBCM)) { $averageBCM = 0; $minBCM = 0; $maxBCM = 0; } 
            else {
                $averageBCM = array_sum($payloadBCM) / count($payloadBCM);
                $minBCM     = min($payloadBCM);
                $maxBCM     = max($payloadBCM);
            }

            $arrays = array(
                'Average Payload' => round($averagePay, 5),
                'Average BCM' => round($averageBCM, 5),
                'Min BCM' => round($minBCM, 5),
                'Max BCM' => round($maxBCM, 5),
                'See detail' => site_url('payload/unit/hd/').$this->my_encryption->encode($sn)
            );
            $data = array();

            foreach ($arrays as $x => $key) {
                $row          = array();
                $row['value'] = $key;
                $row['label'] = $x;
                $data[]       = $row;
            }
            echo json_encode($data);
        }

        public function table_payload($sn){
            $sn          = $this->pregReps($sn);
            $payload     = $this->mod_payload_hd->get_payload($sn);
            $all_payload = $this->mod_payload_hd->get_all_payload($sn);
            $data        = array();
            $no          = $this->pregRepn($this->input->post('start'));

            foreach ($payload as $field){
                $no++;
                $row                = array();
                $row['no']          = $no;
                $row['date']        = date("d-m-Y", strtotime($field->tgl));
                $row['time']        = $field->time;
                $row['payload']     = floatval($field->payload / 10);
                $row['bcm_payload'] = floatval($field->payload / 10 / 2.47);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $row['loader']      = ($field->loader == null) ? "-" : $this->pregReps($field->loader);
                $row['nmloader']    = ($field->nmloader == null) ? "-" : $this->pregReps($field->nmloader);
                $data[]             = $row;
            };
            $payloadValue = $this->array_fungsi($all_payload, 10);
            $payloadBCM   = $this->array_fungsi($all_payload, 10, 2.47);
            if (empty($payloadValue)) { $averagePay = 0;
            } else { $averagePay = array_sum($payloadValue) / count($payloadValue); }
            if (empty($payloadBCM)) { $averageBCM = 0; $minBCM = 0; $maxBCM = 0; } 
            else {
                $averageBCM = array_sum($payloadBCM) / count($payloadBCM);
                $minBCM     = min($payloadBCM);
                $maxBCM     = max($payloadBCM);
            }
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_payload($sn),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_payload($sn),
                "data"            => $data,
                "averageBCM"      => $averageBCM,
                "averagePay"      => $averagePay,
                "maxBCM"          => $maxBCM,
                "minBCM"          => $minBCM,
            );
            echo json_encode($output);
        }

        public function search_table_payload($sn){
            $sn = $this->pregReps($sn);
            $date1      = str_replace("/", "-", $this->input->post('date_start'));
            $date2      = str_replace("/", "-", $this->input->post('date_end'));
            $date_start = date("Y-m-d", strtotime($date1));
            $date_end   = date("Y-m-d", strtotime($date2));

            $payload     = $this->mod_payload_hd->get_spayload($sn, $date_start, $date_end);
            $all_payload = $this->mod_payload_hd->get_average_spayload($sn, $date_start, $date_end);

            $data    = array();
            $no      = $this->pregRepn($this->input->post('start'));

            foreach ($payload as $field) {
                $no++;
                $row                = array();
                $row['no']          = $no;
                $row['date']        = date("d-m-Y", strtotime($field->tgl));
                $row['time']        = $field->time;
                $row['payload']     = floatval($field->payload / 10);
                $row['bcm_payload'] = floatval($field->payload / 10 / 2.47);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $row['loader']      = ($field->loader == null) ? "-" : $this->pregReps($field->loader);
                $row['nmloader']    = ($field->nmloader == null) ? "-" : $this->pregReps($field->nmloader);
                $data[]             = $row;
            }

            $payloadValue = $this->array_fungsi($all_payload, 10);
            $payloadBCM   = $this->array_fungsi($all_payload, 10, 2.47);
            if (empty($payloadValue)) { $averagePay = 0;
            } else { $averagePay = array_sum($payloadValue) / count($payloadValue); }
            if (empty($payloadBCM)) { $averageBCM = 0; $minBCM = 0; $maxBCM = 0; } 
            else {
                $averageBCM = array_sum($payloadBCM) / count($payloadBCM);
                $minBCM     = min($payloadBCM);
                $maxBCM     = max($payloadBCM);
            }

            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_spayload($sn, $date_start, $date_end),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_spayload($sn, $date_start, $date_end),
                "data"            => $data,
                "averageBCM"      => $averageBCM,
                "averagePay"      => $averagePay,
                "maxBCM"          => $maxBCM,
                "minBCM"          => $minBCM,
            );
            echo json_encode($output);
        }

        public function table_empty_drive_time($sn){
            $sn = $this->pregReps($sn);
            $empty_drive_time = $this->mod_payload_hd->get_empty_drive_time($sn);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($empty_drive_time as $field){
                if (date("d-m-Y", strtotime($field->tgl)) == date("d-m-Y") ) {
                    $today_notif = '<span class="label label-success">Today</span>';
                } else {
                    $today_notif = '';
                }
                $no++;
                $row                   = array();
                $row['no']             = $no;
                $row['date']           = date("d-m-Y", strtotime($field->tgl));
                $row['time']           = $field->time;
                $row['emptydrivetime'] = floatval($field->emptydrivetime / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]                = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_empty_drive_time($sn),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_empty_drive_time($sn),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function search_table_empty_drive_time($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);
            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $empty_drive_time = $this->mod_payload_hd->get_search_empty_drive_time($sn, $date_start, $date_end);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($empty_drive_time as $field){
                $no++;
                $row                   = array();
                $row['no']             = $no;
                $row['date']           = date("d-m-Y", strtotime($field->tgl));
                $row['time']           = $field->time;
                $row['emptydrivetime'] = floatval($field->emptydrivetime / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]                = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_search_empty_drive_time($sn, $date_start, $date_end),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_search_empty_drive_time($sn, $date_start, $date_end),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function table_empty_drive_distance($sn){
            $sn = $this->pregReps($sn);
            $empty_drive_distance = $this->mod_payload_hd->get_empty_drive_distance($sn);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($empty_drive_distance as $field){
                $no++;
                $row                   = array();
                $row['no']             = $no;
                $row['date']           = date("d-m-Y", strtotime($field->tgl));
                $row['time']           = $field->time;
                $row['emptydrivedistance'] = floatval($field->emptydrivedistance / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]                = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_empty_drive_distance($sn),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_empty_drive_distance($sn),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function search_table_empty_drive_distance($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);
            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $empty_drive_distance = $this->mod_payload_hd->get_search_empty_drive_distance($sn, $date_start, $date_end);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($empty_drive_distance as $field){
                $no++;
                $row                   = array();
                $row['no']             = $no;
                $row['date']           = date("d-m-Y", strtotime($field->tgl));
                $row['time']           = $field->time;
                $row['emptydrivedistance'] = floatval($field->emptydrivedistance / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]                = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_search_empty_drive_distance($sn, $date_start, $date_end),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_search_empty_drive_distance($sn, $date_start, $date_end),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function table_empty_stop_time($sn){
            $sn = $this->pregReps($sn);
            $empty_stop_time = $this->mod_payload_hd->get_empty_stop_time($sn);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($empty_stop_time as $field){
                $no++;
                $row                   = array();
                $row['no']             = $no;
                $row['date']           = date("d-m-Y", strtotime($field->tgl));
                $row['time']           = $field->time;
                $row['emptystoptime']  = floatval($field->emptystoptime / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]                = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_empty_stop_time($sn),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_empty_stop_time($sn),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function search_table_empty_stop_time($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);
            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $empty_stop_time = $this->mod_payload_hd->get_search_empty_stop_time($sn, $date_start, $date_end);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($empty_stop_time as $field){
                $no++;
                $row                  = array();
                $row['no']            = $no;
                $row['date']          = date("d-m-Y", strtotime($field->tgl));
                $row['time']          = $field->time;
                $row['emptystoptime'] = floatval($field->emptystoptime / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]               = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_search_empty_stop_time($sn, $date_start, $date_end),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_search_empty_stop_time($sn, $date_start, $date_end),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function table_loading_stop_time($sn){
            $sn = $this->pregReps($sn);
            $loading_stop_time = $this->mod_payload_hd->get_loading_stop_time($sn);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($loading_stop_time as $field){
                $no++;
                $row                   = array();
                $row['no']             = $no;
                $row['date']           = date("d-m-Y", strtotime($field->tgl));
                $row['time']           = $field->time;
                $row['loadingstoptime']  = floatval($field->loadingstoptime / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]                = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_loading_stop_time($sn),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_loading_stop_time($sn),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function search_table_loading_stop_time($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);
            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $loading_stop_time = $this->mod_payload_hd->get_search_loading_stop_time($sn, $date_start, $date_end);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($loading_stop_time as $field){
                $no++;
                $row                  = array();
                $row['no']            = $no;
                $row['date']          = date("d-m-Y", strtotime($field->tgl));
                $row['time']          = $field->time;
                $row['loadingstoptime'] = floatval($field->loadingstoptime / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]               = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_search_loading_stop_time($sn, $date_start, $date_end),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_search_loading_stop_time($sn, $date_start, $date_end),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function table_loaded_drive_time($sn){
            $sn = $this->pregReps($sn);
            $loaded_drive_time = $this->mod_payload_hd->get_loaded_drive_time($sn);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($loaded_drive_time as $field){
                $no++;
                $row                    = array();
                $row['no']              = $no;
                $row['date']            = date("d-m-Y", strtotime($field->tgl));
                $row['time']            = $field->time;
                $row['loadeddrivetime'] = floatval($field->loadeddrivetime / 10);
                $row['nik']             = $this->pregRepn($field->nik);
                $row['name']            = $this->pregReps($field->nama);
                $data[]                 = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_loaded_drive_time($sn),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_loaded_drive_time($sn),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function search_table_loaded_drive_time($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);
            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $loaded_drive_time = $this->mod_payload_hd->get_search_loaded_drive_time($sn, $date_start, $date_end);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($loaded_drive_time as $field){
                $no++;
                $row                  = array();
                $row['no']            = $no;
                $row['date']          = date("d-m-Y", strtotime($field->tgl));
                $row['time']          = $field->time;
                $row['loadeddrivetime'] = floatval($field->loadeddrivetime / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]               = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_search_loaded_drive_time($sn, $date_start, $date_end),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_search_loaded_drive_time($sn, $date_start, $date_end),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function table_loaded_stop_time($sn){
            $sn = $this->pregReps($sn);
            $loaded_stop_time = $this->mod_payload_hd->get_loaded_stop_time($sn);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($loaded_stop_time as $field){
                $no++;
                $row                   = array();
                $row['no']             = $no;
                $row['date']           = date("d-m-Y", strtotime($field->tgl));
                $row['time']           = $field->time;
                $row['loadedstoptime']  = floatval($field->loadedstoptime / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]                = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_loaded_stop_time($sn),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_loaded_stop_time($sn),
                "data"            => $data,
            );
            echo json_encode($output);
        }

        public function search_table_loaded_stop_time($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);
            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $loaded_stop_time = $this->mod_payload_hd->get_search_loaded_stop_time($sn, $date_start, $date_end);
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($loaded_stop_time as $field){
                $no++;
                $row                  = array();
                $row['no']            = $no;
                $row['date']          = date("d-m-Y", strtotime($field->tgl));
                $row['time']          = $field->time;
                $row['loadedstoptime'] = floatval($field->loadedstoptime / 10);
                $row['nik']         = ($field->nik == null && $field->nik == '') ? "-" : $this->pregRepn($field->nik);
                $row['name']        = ($field->nama == null && $field->nik == '') ? "-" : $this->pregReps($field->nama);
                $data[]               = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_payload_hd->count_all_search_loaded_stop_time($sn, $date_start, $date_end),
                "recordsFiltered" => $this->mod_payload_hd->count_filtered_search_loaded_stop_time($sn, $date_start, $date_end),
                "data"            => $data,
            );
            echo json_encode($output);
        }


        public function chart_payload($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);

            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $payload = $this->mod_payload_hd->get_chart_payload($sn, $date_start, $date_end);
            foreach ($payload as $row) {
                $data[] = array(
                    'date'    => date("Y-m-d H:i:s", strtotime($row->tgl)),
                    'payload' => floatval($row->payload / 10),
                    'bcm'     => floatval($row->payload / 10 / 2.47),
                    'nik'     => $this->pregRepn($row->nik),
                    'name'    => $this->pregReps($row->nama),
                );
            }
            echo json_encode($data);
        }

        public function chart_emptydrivetime($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);

            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $emptydrivetime = $this->mod_payload_hd->get_chart_empty_drive_time($sn, $date_start, $date_end);
            foreach ($emptydrivetime as $row) {
                $output[] = array(
                    'date'           => date("Y-m-d H:i:s", strtotime($row->tgl)),
                    'emptydrivetime' => floatval($row->emptydrivetime / 10),
                    'nik'            => $this->pregRepn($row->nik),
                    'name'           => $this->pregReps($row->nama),
                );
            }
            echo json_encode($output);
        }

        public function chart_emptydrivedistance($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);

            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $emptydrivedistance = $this->mod_payload_hd->get_chart_empty_drive_distance($sn, $date_start, $date_end);
            foreach ($emptydrivedistance as $row) {
                $output[] = array(
                    'date'           => date("Y-m-d H:i:s", strtotime($row->tgl)),
                    'emptydrivedistance' => floatval($row->emptydrivedistance / 10),
                    'nik'            => $this->pregRepn($row->nik),
                    'name'           => $this->pregReps($row->nama),
                );
            }
            echo json_encode($output);
        }

        public function chart_emptystoptime($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);

            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $emptystoptime = $this->mod_payload_hd->get_chart_empty_stop_time($sn, $date_start, $date_end);
            foreach ($emptystoptime as $row) {
                $output[] = array(
                    'date'          => date("Y-m-d H:i:s", strtotime($row->tgl)),
                    'emptystoptime' => floatval($row->emptystoptime / 10),
                    'nik'           => $this->pregRepn($row->nik),
                    'name'          => $this->pregReps($row->nama),
                );
            }
            echo json_encode($output);
        }

        public function chart_loadingstoptime($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);

            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $loadingstoptime = $this->mod_payload_hd->get_chart_loading_stop_time($sn, $date_start, $date_end);
            foreach ($loadingstoptime as $row) {
                $output[] = array(
                    'date'            => date("Y-m-d H:i:s", strtotime($row->tgl)),
                    'loadingstoptime' => floatval($row->loadingstoptime / 10),
                    'nik'             => $this->pregRepn($row->nik),
                    'name'            => $this->pregReps($row->nama),
                );
            }
            echo json_encode($output);
        }

        public function chart_loadeddrivetime($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);

            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $loadeddrivetime = $this->mod_payload_hd->get_chart_loaded_drive_time($sn, $date_start, $date_end);
            foreach ($loadeddrivetime as $row) {
                $output[] = array(
                    'date'          => date("Y-m-d H:i:s", strtotime($row->tgl)),
                    'loadeddrivetime' => floatval($row->loadeddrivetime / 10),
                    'nik'           => $this->pregRepn($row->nik),
                    'name'          => $this->pregReps($row->nama),
                );
            }
            echo json_encode($output);
        }

        public function chart_loadedstoptime($sn, $date_start_new, $date_end_new){
            $sn = $this->pregReps($sn);

            $date_start = date("Y-m-d", strtotime($this->dateValid($date_start_new)));
            $date_end   = date("Y-m-d", strtotime($this->dateValid($date_end_new)));

            $loadedstoptime = $this->mod_payload_hd->get_chart_loaded_stop_time($sn, $date_start, $date_end);
            foreach ($loadedstoptime as $row) {
                $output[] = array(
                    'date'           => date("Y-m-d H:i:s", strtotime($row->tgl)),
                    'loadedstoptime' => floatval($row->loadedstoptime / 10),
                    'nik'            => $this->pregRepn($row->nik),
                    'name'           => $this->pregReps($row->nama),
                );
            }
            echo json_encode($output);
        }



    }
?>