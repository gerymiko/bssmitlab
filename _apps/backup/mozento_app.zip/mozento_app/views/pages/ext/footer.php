<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/dist-mosento/js/adminlte.min.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/tiket/select2/dist/js/select2.full.min.js"></script>
<!-- <script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/select2/dist/js/select2.full.min.js"></script> -->
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/datatables_bs/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/datatables_bs/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/datatables_bs/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/sweetalert/sweetalert2.min.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/alphanum/jquery.alphanum.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/jquery-validation/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/font-awesome/js/all.min.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/amcharts4/v447/core.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/amcharts4/v447/charts.js"></script>
<!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"></script> -->
<!-- <script type="text/javascript" src="https://www.chartjs.org/samples/latest/utils.js"></script> -->
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/moment/moment.min.js"></script>
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/mosento/daterangepicker/daterangepicker.min.js"></script>

