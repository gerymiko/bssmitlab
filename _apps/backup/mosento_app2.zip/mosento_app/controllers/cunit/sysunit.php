<?php defined('BASEPATH') OR exit('No direct script access allowed');

    class Sysunit extends CI_Controller{

        function __construct(){
            parent::__construct();
            if ($this->session->userdata('nik') == null || $this->session->userdata('tipeapp') != 'MOSENTO') {
                redirect('syslogin');
            }
            $this->load->model(['munit/mod_unit']);
        }

        private static function pregReps($string){ 
            $result = preg_replace('/[^a-zA-Z0-9- _.,]/','', $string);
            return $result;
        }

        private static function pregRepn($number){ 
            $result = preg_replace('/[^0-9]/','', $number);
            return $result;
        }

        public function index(){
        	$data = array(
                'header'  => 'pages/ext/header',
                'footer'  => 'pages/ext/footer',
                'menu'    => 'pages/ptopbar/vtopbar',
                'content' => 'pages/punit/vunit',
        	);
        	$this->load->view('pages/pindex/index', $data);
        }

        public function table_unit(){
            $unit = $this->mod_unit->get_unit();
            $data = array();
            $no   = $this->pregRepn($this->input->post('start'));

            foreach ($unit as $field){

                if ( $field->status == 1 ){
                    $status = '<i class="fas fa-circle text-green" data-toggle="tooltip" title="Active"></i>';
                } else {
                    $status = '<i class="fas fa-circle text-red" data-toggle="tooltip" title="Nonactive"></i>';
                }

                $no++;
                $row                 = array();
                $row['no']           = $no;
                $row['unit']         = $field->unit;
                $row['type']         = $field->type_unit;
                $row['serialnumber'] = $field->serialnumber;
                $row['nolambung']    = $field->nolambung;
                $row['status']       = $status;
                $row['action']       = '
                    <button class="btn btn-xs btn-success">Activated</button>
                    <button class="btn btn-xs btn-warning">Deactivated</button>
                    <button class="btn btn-danger btn-xs" data-toggle="tooltip" title="Delete"><i class="fas fa-trash-alt"></i></button>
                ';
                $data[]              = $row;
            };
            $output = array(
                "draw"            => $this->pregRepn($this->input->post('draw')),
                "recordsTotal"    => $this->mod_unit->count_all_unit(),
                "recordsFiltered" => $this->mod_unit->count_filtered_unit(),
                "data"            => $data,
            );
            echo json_encode($output);
        }

    }
?>