<section class="content-header">
   <h1>
      Privilege
      <small>Access configuration</small>
   </h1>
   <ol class="breadcrumb">
      <li><a href="#">Home</a></li>
      <li class="active">Privilege</li>
   </ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-bluecrown-light"><i class="fas fa-user-shield"></i></span>
				<div class="info-box-content">
					<span class="info-box-text text-black">Total<br> Administrator</span>
					<span class="info-box-number">3</span>
				</div>
			</div>
		</div>
		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-bluecrown-light"><i class="fas fa-user-friends"></i></span>
				<div class="info-box-content">
					<span class="info-box-text text-black">Total<br> Public User</span>
					<span class="info-box-number">6</span>
				</div>
			</div>
		</div>
	</div>
	<div class="box box-primary">
		<div class="box-header with-border">
			<h3 class="box-title">List User</h3>
			<div class="box-tools pull-right">
				<button type="button" class="btn btn-xs btn-primary"><i class="fa fa-plus"></i> Add User</button>
			</div>
		</div>
		<div class="box-body">
			<table id="table_privilege" class="table table-bordered table-hover nowrap" style="width:100%">
				<thead class="bg-dark-gray">
					<tr>
						<th>#</th>
						<th>NIK</th>
						<th>Fullname</th>
						<th>Email</th>
						<th>Type</th>
						<th>Username</th>
						<th>Last Login</th>
						<th><i class="fas fa-cogs"></i></th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</section>
<script type="text/javascript">
   	$(document).ready(function (){
	   	var table = $('#table_privilege').DataTable({
	   		"processing": true,
	   		"serverSide": true,
	   		"responsive": true,
	   		"scrollX": true,
	   		"order": [],
	   		"ajax": {
	   			"url": '<?=site_url()?>cprivilege/sysprivilege/table_privilege',
	   			"type": 'POST',
	   			error: function(data) {
	   				swal("Oops!", "Failed to pull data. Reload page and try again", "error");
	   			},
	   		},
	   		"language": { 
	   			"processing": 
	   			'<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
	   		},
	   		"columns": [
		   		{ "data": "no", "className": "text-center", "searchable": false, "orderable": false },
		   		{ "data": "nik", "className": "text-center" },
		   		{ "data": "nama", "className": "text-left", "orderable": false },
		   		{ "data": "email", "className": "text-center", "orderable": false },
		   		{ "data": "type", "className": "text-center", "orderable": false  },
		   		{ "data": "username", "className": "text-center", "orderable": false  },
		   		{ "data": "last_login", "className": "text-center", "orderable": false  },
		   		{ "data": "action", "className": "text-center", "orderable": false  },
	   		]
	   	});
	});
</script>