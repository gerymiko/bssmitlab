<section class="content-header">
    <h1>Unit <?=$detail_exca->nolambung;?></h1>
    <ol class="breadcrumb">
        <li><a href="<?=site_url();?>cpanel/syspanel">Home</a></li>
        <li>Detail</li>
        <li class="active"><?=$detail_exca->nolambung;?></li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-3">
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title"></h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <div class="text-center">
                        <img src="<?=site_url();?>syslink/icon_exca" width="200" />
                    </div>
                </div>
                <div class="box-footer no-padding">
                    <ul class="nav nav-pills nav-stacked">
                        <li>
                            <a href="#">Excavator
                            <span class="pull-right"><b><?=$detail_exca->unit;?></b></span></a>
                        </li>
                        <li>
                            <a href="#">Serial Number 
                            <span class="pull-right"><b><?=$detail_exca->serialnumber;?></b></span></a>
                        </li>
                        <li>
                            <a href="#">Status
                            <span class="pull-right label <?=($detail_exca->status == 1) ? 'label-success' : 'label-danger';?>"><?=($detail_exca->status == 1) ? 'Active' : 'Non-Active';?></span></a>
                        </li>
                        <li>
                            <a href="#">Site
                            <span class="pull-right"><?=($site_unit->servername == null) ? 'Data not found' : $site_unit->servername;?></span></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="info-box" style="min-height: 55px;">
                <span class="info-box-icon bg-blue" style="height: 55px;width: 55px;font-size: 30px;line-height: 55px;"><i class="fas fa-calendar-check"></i></span>
                <div class="info-box-content" style="margin-left: 55px;">
                    <span class="info-box-text">LAST UPDATE DATA</span>
                    <span class="info-box-number f14"><?=($detail_exca->lastupdate == null ) ? "Data not updated" : date("d-m-Y H:i A", strtotime($detail_exca->lastupdate));?></span>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Warning Status</h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <table id="table_warning_unit" class="table table-bordered table-hover nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th class="text-center bg-white">Messages</th>
                                <th>Mensaje</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>

            <div class="nav-tabs-custom" id="content1" style="display: none;">
                <ul class="nav nav-tabs pull-right" id="myTabs">
                    <li class="active"><a href="#chart_oil" data-toggle="tab">Chart</a></li>
                    <li><a href="#data_oil" data-toggle="tab">Data</a></li>
                    <li class="pull-left header">Engine Oil Temperatures</li>
                </ul>
                <div class="tab-content">
                    <div class="active tab-pane" id="chart_oil">
                        <div class="chart-responsive">
                            <div class="chart" id="oil-temperature-chart" style="height: 450px;"></div>
                        </div>
                    </div>
                    <div class="tab-pane" id="data_oil">
                        <table id="table_engine_oil_temperature" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Temperatures (DegC)</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>

            <div class="nav-tabs-custom" id="content2" style="display: none;">
                <ul class="nav nav-tabs pull-right">
                    <li class="active"><a href="#chart_fuel" data-toggle="tab">Chart</a></li>
                    <li><a href="#data_fuel" data-toggle="tab">Data</a></li>
                    <li class="pull-left header">Fuel Rate</li>
                </ul>
                <div class="tab-content">
                    <div class="active tab-pane" id="chart_fuel">
                        <div class="chart-responsive">
                          <div class="chart" id="fuelrate-chart" style="height: 450px;"></div>
                        </div>
                    </div>
                    <div class="tab-pane" id="data_fuel">
                        <table id="table_fuel_rate" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Rate (liter / Hour)</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>

            <div class="nav-tabs-custom" id="content3" style="display: none;">
                <ul class="nav nav-tabs pull-right">
                    <li class="active"><a href="#chart_transmission_oiltemp" data-toggle="tab">Chart</a></li>
                    <li><a href="#data_transmission_oiltemp" data-toggle="tab">Data</a></li>
                    <li class="pull-left header">Transmission Oil Temperature</li>
                </ul>
                <div class="tab-content">
                    <div class="active tab-pane" id="chart_transmission_oiltemp">
                        <div class="chart-responsive">
                          <div class="chart" id="transmission_oiltemp-chart" style="height: 450px;"></div>
                        </div>
                    </div>
                    <div class="tab-pane" id="data_transmission_oiltemp">
                        <table id="table_transmission_oil_temp" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Temperatures (DegC)</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>

            <div class="nav-tabs-custom" id="content4" style="display: none;">
                <ul class="nav nav-tabs pull-right">
                    <li class="active"><a href="#chart_engine_coolant_temp" data-toggle="tab">Chart</a></li>
                    <li><a href="#data_engine_coolant_temp" data-toggle="tab">Data</a></li>
                    <li class="pull-left header">Engine Coolant Temperature</li>
                </ul>
                <div class="tab-content">
                    <div class="active tab-pane" id="chart_engine_coolant_temp">
                        <div class="chart-responsive">
                          <div class="chart" id="engine-coolant-temp-chart" style="height: 450px;"></div>
                        </div>
                    </div>
                    <div class="tab-pane" id="data_engine_coolant_temp">
                        <table id="table_engine_coolant_temp" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Temperatures (DegC)</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>

            <div class="nav-tabs-custom" id="content5" style="display: none;">
                <ul class="nav nav-tabs pull-right">
                    <li class="active"><a href="#chart_blow_by_pressure" data-toggle="tab">Chart</a></li>
                    <li><a href="#data_blow_by_pressure" data-toggle="tab">Data</a></li>
                    <li class="pull-left header">Blow By Pressure</li>
                </ul>
                <div class="tab-content">
                    <div class="active tab-pane" id="chart_blow_by_pressure">
                        <div class="chart-responsive">
                          <div class="chart" id="blow-by-pressure-chart" style="height: 450px;"></div>
                        </div>
                    </div>
                    <div class="tab-pane" id="data_blow_by_pressure">
                        <table id="table_blow_by_pressure" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Pressure (mmAq)</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>

            <div class="nav-tabs-custom" id="content6" style="display: none;">
                <ul class="nav nav-tabs pull-right">
                    <li class="active"><a href="#chart_boost_pressure" data-toggle="tab">Chart</a></li>
                    <li><a href="#data_boost_pressure" data-toggle="tab">Data</a></li>
                    <li class="pull-left header">Boost Pressure</li>
                </ul>
                <div class="tab-content">
                    <div class="active tab-pane" id="chart_boost_pressure">
                        <div class="chart-responsive">
                          <div class="chart" id="boost-pressure-chart" style="height: 450px;"></div>
                        </div>
                    </div>
                    <div class="tab-pane" id="data_boost_pressure">
                        <table id="table_boost_pressure" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Pressure (mmHg)</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<script type="text/javascript">
    $(document).ready(function (){
        $("#content1").slideUp(300).delay(100).fadeIn(400);
        $("#content2").slideUp(300).delay(200).fadeIn(400);
        $("#content3").slideUp(300).delay(300).fadeIn(400);
        $("#content4").slideUp(300).delay(400).fadeIn(400);
        $("#content5").slideUp(300).delay(500).fadeIn(400);
        $("#content6").slideUp(300).delay(600).fadeIn(400);

        $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
        });

        var table1 = $('#table_warning_unit').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "scrollX": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cdetail/exca/sysdetail_exca/table_warning_unit/<?=$this->encrypt->encode($detail_exca->serialnumber);?>',
                "type": 'POST',
                error: function(data) {
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center" },
                { "data": "time", "className": "text-center", "orderable": false },
                { "data": "messages", "className": "text-left", "orderable": false },
                { "data": "mensaje", "className": "text-center", "visible": false },
            ],
            "createdRow": function( row, data, dataIndex){
                if( data['mensaje'] == 'CRITICAL'){
                    $(row).addClass('bg-red');
                } else {
                    $(row).addClass('bg-yellow');
                }
            },
        });

        var table2 = $('#table_engine_oil_temperature').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cdetail/exca/sysdetail_exca/table_engine_oil_temperature/<?=$this->encrypt->encode($detail_exca->serialnumber);?>',
                "type": 'POST',
                error: function(data) {
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center" },
                { "data": "time", "className": "text-center" },
                { "data": "temperature", "className": "text-center", "orderable": false },
            ],
        });

        var table3 = $('#table_fuel_rate').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cdetail/exca/sysdetail_exca/table_fuel_rate/<?=$this->encrypt->encode($detail_exca->serialnumber);?>',
                "type" : 'POST',
                error: function(data) {
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center" },
                { "data": "time", "className": "text-center" },
                { "data": "fuel", "className": "text-center", "orderable": false },
            ],
        });

        var table4 = $('#table_transmission_oil_temp').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cdetail/exca/sysdetail_exca/table_transmission_oil_temperature/<?=$this->encrypt->encode($detail_exca->serialnumber);?>',
                "type" : 'POST',
                error: function(data) {
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center" },
                { "data": "time", "className": "text-center" },
                { "data": "tmoiltemp", "className": "text-center", "orderable": false },
            ],
        });

        var table5 = $('#table_engine_coolant_temp').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cdetail/exca/sysdetail_exca/table_engine_coolant_temperature/<?=$this->encrypt->encode($detail_exca->serialnumber);?>',
                "type" : 'POST',
                error: function(data) {
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center" },
                { "data": "time", "className": "text-center" },
                { "data": "cooltemp", "className": "text-center", "orderable": false },
            ],
        });

        var table6 = $('#table_blow_by_pressure').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cdetail/exca/sysdetail_exca/table_blow_by_pressure/<?=$this->encrypt->encode($detail_exca->serialnumber);?>',
                "type" : 'POST',
                error: function(data) {
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center" },
                { "data": "time", "className": "text-center" },
                { "data": "blowbypress", "className": "text-center", "orderable": false },
            ],
        });

        var table7 = $('#table_boost_pressure').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cdetail/exca/sysdetail_exca/table_boost_pressure/<?=$this->encrypt->encode($detail_exca->serialnumber);?>',
                "type": 'POST',
                error: function(data) {
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center" },
                { "data": "time", "className": "text-center" },
                { "data": "boostpress", "className": "text-center", "orderable": false },
            ],
        });

        am4core.ready(function() {
            var chart = am4core.create("oil-temperature-chart", am4charts.XYChart);
            chart.responsive.enabled = true;
            chart.preloader.disabled = true;
            var indicator;
            function showIndicator() {
                if (indicator) {
                    indicator.show();
                } else {
                    indicator = chart.tooltipContainer.createChild(am4core.Container);
                    indicator.background.fill = am4core.color("#fff");
                    indicator.background.fillOpacity = 1.00;
                    indicator.width = am4core.percent(100);
                    indicator.height = am4core.percent(100);

                    var indicatorLabel = indicator.createChild(am4core.Label);
                    indicatorLabel.text = "No data...";
                    indicatorLabel.align = "center";
                    indicatorLabel.valign = "middle";
                    indicatorLabel.fontSize = 20;
                }
            }
            function hideIndicator() { indicator.hide(); }
            chart.events.on("beforevalidated", function(ev) {
                if (ev.target.data.length == 0) {
                    showIndicator();
                } else if (indicator) {
                    hideIndicator();
                }
            });
            chart.dataSource.url = "<?=site_url();?>cdetail/exca/sysdetail_exca/chart_engine_oil_temperature/<?=$this->encrypt->encode($detail_exca->serialnumber);?>";

            var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
            dateAxis.renderer.minGridDistance = 100;
            dateAxis.renderer.grid.template.disabled = true;
            var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
            valueAxis.title.text = "Temperature DegC";

            var series = chart.series.push(new am4charts.LineSeries());
            series.dataFields.valueY = "temp";
            series.dataFields.dateX = "date";
            series.name = "Temperature Oil";
            series.tooltipText = "{name}: [bold]{valueY}[/]";
            series.strokeWidth = 2;

            var series2 = chart.series.push(new am4charts.LineSeries());
            series2.dataFields.valueY = "critical";
            series2.dataFields.dateX = "date";
            series2.name = "Critical";
            series2.tooltipText = "{name}: [bold]{valueY}[/]";
            series2.strokeWidth = 2;
            series2.yAxis = valueAxis;
            series2.stroke = am4core.color("red");

            var series3 = chart.series.push(new am4charts.LineSeries());
            series3.dataFields.valueY = "caution";
            series3.dataFields.dateX = "date";
            series3.name = "Caution";
            series3.tooltipText = "{name}: [bold]{valueY}[/]";
            series3.strokeWidth = 2;
            series3.yAxis = valueAxis;
            series3.stroke = am4core.color("yellow");

            chart.legend = new am4charts.Legend();
            chart.cursor = new am4charts.XYCursor();
            chart.cursor.behavior = "panXY";
            chart.cursor.xAxis = dateAxis;
            chart.cursor.snapToSeries = series;

            var bullet = series.bullets.push(new am4charts.CircleBullet());
            bullet.circle.strokeWidth = 2;
            bullet.circle.radius = 3;
            bullet.circle.fill = am4core.color("#fff");

            chart.maskBullets = false;
        });

        am4core.ready(function() {
            var chart = am4core.create("fuelrate-chart", am4charts.XYChart);
            chart.responsive.enabled = true;
            chart.preloader.disabled = true;
            var indicator;
            function showIndicator() {
                if (indicator) {
                    indicator.show();
                } else {
                    indicator = chart.tooltipContainer.createChild(am4core.Container);
                    indicator.background.fill = am4core.color("#fff");
                    indicator.background.fillOpacity = 1.00;
                    indicator.width = am4core.percent(100);
                    indicator.height = am4core.percent(100);

                    var indicatorLabel = indicator.createChild(am4core.Label);
                    indicatorLabel.text = "No data...";
                    indicatorLabel.align = "center";
                    indicatorLabel.valign = "middle";
                    indicatorLabel.fontSize = 20;
                }
            }
            function hideIndicator() { indicator.hide(); }
            chart.events.on("beforevalidated", function(ev) {
                if (ev.target.data.length == 0) {
                    showIndicator();
                } else if (indicator) {
                    hideIndicator();
                }
            });
            chart.dataSource.url = "<?=site_url();?>cdetail/exca/sysdetail_exca/chart_fuel_rate/<?=$this->encrypt->encode($detail_exca->serialnumber);?>";

            var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
            dateAxis.renderer.minGridDistance = 100;
            dateAxis.renderer.grid.template.disabled = true;
            var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
            valueAxis.title.text = "Liter / Hour";

            var series = chart.series.push(new am4charts.LineSeries());
            series.dataFields.valueY = "fuel";
            series.dataFields.dateX = "date";
            series.name = "Liter / Hour";
            series.tooltipText = "{name}: [bold]{valueY}[/]";
            series.strokeWidth = 2;

            var series2 = chart.series.push(new am4charts.LineSeries());
            series2.dataFields.valueY = "critical";
            series2.dataFields.dateX = "date";
            series2.name = "Critical";
            series2.tooltipText = "{name}: [bold]{valueY}[/]";
            series2.strokeWidth = 2;
            series2.yAxis = valueAxis;
            series2.stroke = am4core.color("red");

            var series3 = chart.series.push(new am4charts.LineSeries());
            series3.dataFields.valueY = "caution";
            series3.dataFields.dateX = "date";
            series3.name = "Caution";
            series3.tooltipText = "{name}: [bold]{valueY}[/]";
            series3.strokeWidth = 2;
            series3.yAxis = valueAxis;
            series3.stroke = am4core.color("yellow");

            chart.legend = new am4charts.Legend();
            chart.cursor = new am4charts.XYCursor();
            chart.cursor.behavior = "panXY";
            chart.cursor.xAxis = dateAxis;
            chart.cursor.snapToSeries = series;

            var bullet = series.bullets.push(new am4charts.CircleBullet());
            bullet.circle.strokeWidth = 2;
            bullet.circle.radius = 3;
            bullet.circle.fill = am4core.color("#fff");

            chart.maskBullets = false;
        });

        am4core.ready(function() {
            var chart = am4core.create("transmission_oiltemp-chart", am4charts.XYChart);
            chart.responsive.enabled = true;
            chart.preloader.disabled = true;
            var indicator;
            function showIndicator() {
                if (indicator) {
                    indicator.show();
                } else {
                    indicator = chart.tooltipContainer.createChild(am4core.Container);
                    indicator.background.fill = am4core.color("#fff");
                    indicator.background.fillOpacity = 1.00;
                    indicator.width = am4core.percent(100);
                    indicator.height = am4core.percent(100);

                    var indicatorLabel = indicator.createChild(am4core.Label);
                    indicatorLabel.text = "No data...";
                    indicatorLabel.align = "center";
                    indicatorLabel.valign = "middle";
                    indicatorLabel.fontSize = 20;
                }
            }
            function hideIndicator() { indicator.hide(); }
            chart.events.on("beforevalidated", function(ev) {
                if (ev.target.data.length == 0) {
                    showIndicator();
                } else if (indicator) {
                    hideIndicator();
                }
            });
            chart.dataSource.url = "<?=site_url();?>cdetail/exca/sysdetail_exca/chart_transmission_oil_temperature/<?=$this->encrypt->encode($detail_exca->serialnumber);?>";

            var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
            dateAxis.renderer.minGridDistance = 100;
            dateAxis.renderer.grid.template.disabled = true;
            var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
            valueAxis.title.text = "Temperature DegC";

            var series = chart.series.push(new am4charts.LineSeries());
            series.dataFields.valueY = "tmoiltemp";
            series.dataFields.dateX = "date";
            series.name = "Temperature DegC";
            series.tooltipText = "{name}: [bold]{valueY}[/]";
            series.strokeWidth = 2;

            var series2 = chart.series.push(new am4charts.LineSeries());
            series2.dataFields.valueY = "critical";
            series2.dataFields.dateX = "date";
            series2.name = "Critical";
            series2.tooltipText = "{name}: [bold]{valueY}[/]";
            series2.strokeWidth = 2;
            series2.yAxis = valueAxis;
            series2.stroke = am4core.color("red");

            var series3 = chart.series.push(new am4charts.LineSeries());
            series3.dataFields.valueY = "caution";
            series3.dataFields.dateX = "date";
            series3.name = "Caution";
            series3.tooltipText = "{name}: [bold]{valueY}[/]";
            series3.strokeWidth = 2;
            series3.yAxis = valueAxis;
            series3.stroke = am4core.color("yellow");

            chart.legend = new am4charts.Legend();
            chart.cursor = new am4charts.XYCursor();
            chart.cursor.behavior = "panXY";
            chart.cursor.xAxis = dateAxis;
            chart.cursor.snapToSeries = series;

            var bullet = series.bullets.push(new am4charts.CircleBullet());
            bullet.circle.strokeWidth = 2;
            bullet.circle.radius = 3;
            bullet.circle.fill = am4core.color("#fff");

            chart.maskBullets = false;
        });

        am4core.ready(function() {
            var chart = am4core.create("engine-coolant-temp-chart", am4charts.XYChart);
            chart.responsive.enabled = true;
            chart.preloader.disabled = true;
            var indicator;
            function showIndicator() {
                if (indicator) {
                    indicator.show();
                } else {
                    indicator = chart.tooltipContainer.createChild(am4core.Container);
                    indicator.background.fill = am4core.color("#fff");
                    indicator.background.fillOpacity = 1.00;
                    indicator.width = am4core.percent(100);
                    indicator.height = am4core.percent(100);

                    var indicatorLabel = indicator.createChild(am4core.Label);
                    indicatorLabel.text = "No data...";
                    indicatorLabel.align = "center";
                    indicatorLabel.valign = "middle";
                    indicatorLabel.fontSize = 20;
                }
            }
            function hideIndicator() { indicator.hide(); }
            chart.events.on("beforevalidated", function(ev) {
                if (ev.target.data.length == 0) {
                    showIndicator();
                } else if (indicator) {
                    hideIndicator();
                }
            });
            chart.dataSource.url = "<?=site_url();?>cdetail/exca/sysdetail_exca/chart_engine_coolant_temperature/<?=$this->encrypt->encode($detail_exca->serialnumber);?>";

            var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
            dateAxis.renderer.minGridDistance = 100;
            dateAxis.renderer.grid.template.disabled = true;
            var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
            valueAxis.title.text = "Temperature DegC";

            var series = chart.series.push(new am4charts.LineSeries());
            series.dataFields.valueY = "cooltemp";
            series.dataFields.dateX = "date";
            series.name = "Temperature DegC";
            series.tooltipText = "{name}: [bold]{valueY}[/]";
            series.strokeWidth = 2;

            var series2 = chart.series.push(new am4charts.LineSeries());
            series2.dataFields.valueY = "critical";
            series2.dataFields.dateX = "date";
            series2.name = "Critical";
            series2.tooltipText = "{name}: [bold]{valueY}[/]";
            series2.strokeWidth = 2;
            series2.yAxis = valueAxis;
            series2.stroke = am4core.color("red");

            var series3 = chart.series.push(new am4charts.LineSeries());
            series3.dataFields.valueY = "caution";
            series3.dataFields.dateX = "date";
            series3.name = "Caution";
            series3.tooltipText = "{name}: [bold]{valueY}[/]";
            series3.strokeWidth = 2;
            series3.yAxis = valueAxis;
            series3.stroke = am4core.color("yellow");

            chart.legend = new am4charts.Legend();
            chart.cursor = new am4charts.XYCursor();
            chart.cursor.behavior = "panXY";
            chart.cursor.xAxis = dateAxis;
            chart.cursor.snapToSeries = series;

            var bullet = series.bullets.push(new am4charts.CircleBullet());
            bullet.circle.strokeWidth = 2;
            bullet.circle.radius = 3;
            bullet.circle.fill = am4core.color("#fff");

            chart.maskBullets = false;
        });

        am4core.ready(function() {
            var chart = am4core.create("blow-by-pressure-chart", am4charts.XYChart);
            chart.responsive.enabled = true;
            chart.preloader.disabled = true;
            var indicator;
            function showIndicator() {
                if (indicator) {
                    indicator.show();
                } else {
                    indicator = chart.tooltipContainer.createChild(am4core.Container);
                    indicator.background.fill = am4core.color("#fff");
                    indicator.background.fillOpacity = 1.00;
                    indicator.width = am4core.percent(100);
                    indicator.height = am4core.percent(100);

                    var indicatorLabel = indicator.createChild(am4core.Label);
                    indicatorLabel.text = "No data...";
                    indicatorLabel.align = "center";
                    indicatorLabel.valign = "middle";
                    indicatorLabel.fontSize = 20;
                }
            }
            function hideIndicator() { indicator.hide(); }
            chart.events.on("beforevalidated", function(ev) {
                if (ev.target.data.length == 0) {
                    showIndicator();
                } else if (indicator) {
                    hideIndicator();
                }
            });
            chart.dataSource.url = "<?=site_url();?>cdetail/exca/sysdetail_exca/chart_blow_by_pressure/<?=$this->encrypt->encode($detail_exca->serialnumber);?>";

            var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
            dateAxis.renderer.minGridDistance = 100;
            dateAxis.renderer.grid.template.disabled = true;
            var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
            valueAxis.title.text = "Pressure (mmAq)";

            var series = chart.series.push(new am4charts.LineSeries());
            series.dataFields.valueY = "blowbypress";
            series.dataFields.dateX = "date";
            series.name = "Pressure (mmAq)";
            series.tooltipText = "{name}: [bold]{valueY}[/]";
            series.strokeWidth = 2;

            var series2 = chart.series.push(new am4charts.LineSeries());
            series2.dataFields.valueY = "critical";
            series2.dataFields.dateX = "date";
            series2.name = "Critical";
            series2.tooltipText = "{name}: [bold]{valueY}[/]";
            series2.strokeWidth = 2;
            series2.yAxis = valueAxis;
            series2.stroke = am4core.color("red");

            var series3 = chart.series.push(new am4charts.LineSeries());
            series3.dataFields.valueY = "caution";
            series3.dataFields.dateX = "date";
            series3.name = "Caution";
            series3.tooltipText = "{name}: [bold]{valueY}[/]";
            series3.strokeWidth = 2;
            series3.yAxis = valueAxis;
            series3.stroke = am4core.color("yellow");

            chart.legend = new am4charts.Legend();
            chart.cursor = new am4charts.XYCursor();
            chart.cursor.behavior = "panXY";
            chart.cursor.xAxis = dateAxis;
            chart.cursor.snapToSeries = series;

            var bullet = series.bullets.push(new am4charts.CircleBullet());
            bullet.circle.strokeWidth = 2;
            bullet.circle.radius = 3;
            bullet.circle.fill = am4core.color("#fff");

            chart.maskBullets = false;
        });

        am4core.ready(function() {
            var chart = am4core.create("boost-pressure-chart", am4charts.XYChart);
            chart.responsive.enabled = true;
            chart.preloader.disabled = true;
            var indicator;
            function showIndicator() {
                if (indicator) {
                    indicator.show();
                } else {
                    indicator = chart.tooltipContainer.createChild(am4core.Container);
                    indicator.background.fill = am4core.color("#fff");
                    indicator.background.fillOpacity = 1.00;
                    indicator.width = am4core.percent(100);
                    indicator.height = am4core.percent(100);

                    var indicatorLabel = indicator.createChild(am4core.Label);
                    indicatorLabel.text = "No data...";
                    indicatorLabel.align = "center";
                    indicatorLabel.valign = "middle";
                    indicatorLabel.fontSize = 20;
                }
            }
            function hideIndicator() { indicator.hide(); }
            chart.events.on("beforevalidated", function(ev) {
                if (ev.target.data.length == 0) {
                    showIndicator();
                } else if (indicator) {
                    hideIndicator();
                }
            });
            chart.dataSource.url = "<?=site_url();?>cdetail/exca/sysdetail_exca/chart_boost_pressure/<?=$this->encrypt->encode($detail_exca->serialnumber);?>";

            var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
            dateAxis.renderer.minGridDistance = 100;
            dateAxis.renderer.grid.template.disabled = true;
            var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
            valueAxis.title.text = "Pressure (mmHg)";

            var series = chart.series.push(new am4charts.LineSeries());
            series.dataFields.valueY = "boostpress";
            series.dataFields.dateX = "date";
            series.name = "Pressure (mmHg)";
            series.tooltipText = "{name}: [bold]{valueY}[/]";
            series.strokeWidth = 2;

            var series2 = chart.series.push(new am4charts.LineSeries());
            series2.dataFields.valueY = "critical";
            series2.dataFields.dateX = "date";
            series2.name = "Critical";
            series2.tooltipText = "{name}: [bold]{valueY}[/]";
            series2.strokeWidth = 2;
            series2.yAxis = valueAxis;
            series2.stroke = am4core.color("red");

            var series3 = chart.series.push(new am4charts.LineSeries());
            series3.dataFields.valueY = "caution";
            series3.dataFields.dateX = "date";
            series3.name = "Caution";
            series3.tooltipText = "{name}: [bold]{valueY}[/]";
            series3.strokeWidth = 2;
            series3.yAxis = valueAxis;
            series3.stroke = am4core.color("yellow");

            chart.legend = new am4charts.Legend();
            chart.cursor = new am4charts.XYCursor();
            chart.cursor.behavior = "panXY";
            chart.cursor.xAxis = dateAxis;
            chart.cursor.snapToSeries = series;

            var bullet = series.bullets.push(new am4charts.CircleBullet());
            bullet.circle.strokeWidth = 2;
            bullet.circle.radius = 3;
            bullet.circle.fill = am4core.color("#fff");

            chart.maskBullets = false;
        });

    });

</script>