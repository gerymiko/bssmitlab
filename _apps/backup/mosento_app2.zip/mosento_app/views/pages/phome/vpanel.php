<section class="content-header">
   <h1>Dashboard <small>Control panel</small></h1>
   <ol class="breadcrumb">
      <li><a href="#">Home</a></li>
      <li class="active">Dashboard</li>
   </ol>
</section>

<section class="content">
   <div class="row">
      <div class="col-md-3 col-sm-6 col-xs-12">
         <a href="<?=site_url();?>cunit/sysunit" class="hand" data-toggle="tooltip" title="See More">
         <div class="info-box">
            <span class="info-box-icon bg-aqua"><?=$count_unit;?></span>
            <div class="info-box-content">
               <span class="info-box-text text-black">Registered<br> Unit</span>
               <span><em>See More</em></span>
            </div>
         </div>
         </a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12">
         <a href="<?=site_url();?>ccritical/syscritical" class="hand" data-toggle="tooltip" title="See More">
         <div class="info-box">
            <span class="info-box-icon bg-red"><?=$count_critical_today;?></span>
            <div class="info-box-content">
               <span class="info-box-text text-black">Today <b>Critical</b><br> Report</span>
               <span><em>See More</em></span>
            </div>
         </div>
         </a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12">
         <a href="<?=site_url();?>ccaution/syscaution" class="hand" data-toggle="tooltip" title="See More">
         <div class="info-box">
            <span class="info-box-icon bg-orange"><?=$count_caution_today;?></span>
            <div class="info-box-content">
               <span class="info-box-text text-black">Today <b>Caution</b><br> Report</span>
               <span><em>See More</em></span>
            </div>
         </div>
         </a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12">
         <a href="<?=site_url();?>cfault/sysfault" class="hand" data-toggle="tooltip" title="See More">
         <div class="info-box">
            <span class="info-box-icon bg-yellow"><?=$count_fault_today;?></span>
            <div class="info-box-content">
               <span class="info-box-text text-black">Today <b>Fault</b> and<br> <b>Warning</b> Report</span>
               <span><em>See More</em></span>
            </div>
         </div>
         </a>
      </div>
   </div>

   <div class="row">
      <div class="col-md-6">
         <div class="box">
            <div class="box-header with-border bg-gray">
               <img src="<?=site_url();?>syslink/icon_exca" alt="Excavator" width="100" >
               <h3 class="box-title text-bold desktop"> EXCAVATOR</h3>
               <div class="box-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                     <input type="text" name="exca_search" id="exca_search" class="form-control pull-right" placeholder="Search">
                     <div class="input-group-btn">
                        <button class="btn btn-default"><i class="fa fa-search"></i></button>
                     </div>
                  </div>
                  <br>
                  <h3 class="box-title text-bold mobile"> EXCAVATOR</h3>
               </div>
            </div>
            <div class="box-body table-responsive no-padding">
               <table id="table_unit_exca" class="table table-hover">
                  <thead>
                     <tr>
                        <th>#</th>
                        <th>Unit</th>
                        <th>Serial Number</th>
                        <th>Warning &amp; Fault</th>
                        <th>Payload</th>
                        <th></th>
                     </tr>
                  </thead>
                  <tbody></tbody>
               </table>
            </div>
         </div>
      </div>
      <div class="col-md-6">
         <div class="box">
            <div class="box-header with-border bg-gray">
               <img src="<?=site_url();?>syslink/icon_hd" alt="Heavy Dump Truck" width="100">
               <h3 class="box-title desktop text-bold">HEAVY DUMP TRUCK</h3>
               <div class="box-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                     <input type="text" name="hd_search" id="hd_search" class="form-control pull-right" placeholder="Search">
                     <div class="input-group-btn">
                        <button class="btn btn-default"><i class="fa fa-search"></i></button>
                     </div>
                  </div>
                  <br>
                  <h3 class="box-title mobile text-bold">HD TRUCK</h3>
               </div>
            </div>
            <div class="box-body table-responsive no-padding">
               <table id="table_unit_hd" class="table table-hover">
                  <thead>
                     <tr>
                        <th>#</th>
                        <th>Unit</th>
                        <th>Serial Number</th>
                        <th>Warning &amp; Fault</th>
                        <th>Payload</th>
                        <th></th>
                     </tr>
                  </thead>
               </table>
            </div>
         </div>
      </div>
   </div>
</section>

<style type="text/css">
   .dataTables_filter{ display:none; }
   #table_unit_exca_paginate, #table_unit_hd_paginate { display:none !important; }
   tr.group, tr.group:hover { background-color: #F5F5F5 !important; font-weight: 600; }
</style>

<script type="text/javascript">
   $(document).ready(function () {
      var groupColumnExca = 1;
      var tableExca = $('#table_unit_exca').DataTable({
         "processing": true,
         "serverSide": true,
         "bInfo": false,
         "bLengthChange": false,
         "order": [[ groupColumnExca, 'asc' ]],
         "ajax": {
            "url"  : '<?=site_url()?>cpanel/syspanel/table_unit_exca',
            "type" : 'POST',
            error: function(data){
               swal("Oops!", "Failed to pull data. Reload page and try again", "error");
            },
            dataFilter:function(response){ return response;},
         },
         "language": { 
            "processing": 
               '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
         },
         "columns": [
            { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
            { "data": "unit", "className": "text-left", "visible": false },
            { "data": "serial", "className": "text-center", "orderable": false },
            { "data": "warningfault", "className": "text-center", "orderable": false },
            { "data": "payload", "className": "text-center", "orderable": false },
            { "data": "status", "className": "text-center", "orderable": false },
         ],
         "drawCallback": function ( settings ) {
            var api = this.api(), rows = api.rows( { page:'current' } ).nodes(), last = null;
            api.column(groupColumnExca, { page:'current' } ).data().each( function ( group, i ){
               if ( last !== group ) {
                  $(rows).eq( i ).before( '<tr class="group"><td colspan="5">'+group+'</td></tr>' );
                  last = group;
               }
            });
         }
      });

      $('#exca_search').keyup(function(){ tableExca.search($(this).val()).draw(); });

      $('#table_unit_exca tbody').on( 'click', 'tr.group', function (){
         var currentOrder = tableExca.order()[0];
         if ( currentOrder[0] === groupColumnExca && currentOrder[1] === 'asc' ){
            tableExca.order( [ groupColumnExca, 'desc' ] ).draw();
         } else {
            tableExca.order( [ groupColumnExca, 'asc' ] ).draw();
         }
      });

      var groupColumnHD = 1;
      var tableHD = $('#table_unit_hd').DataTable({
         "processing": true,
         "serverSide": true,
         "bInfo": false,
         "bLengthChange": false,
         "order": [[ groupColumnHD, 'asc' ]],
         "ajax": {
            "url"  : '<?=site_url()?>cpanel/syspanel/table_unit_hd',
            "type" : 'POST',
            error: function(data){
               swal("Oops!", "Failed to pull data. Reload page and try again", "error");
            },
            dataFilter:function(response){ return response;},
         },
         "language": { 
            "processing": 
               '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
         },
         "columns": [
            { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
            { "data": "unit", "className": "text-left", "visible": false },
            { "data": "serial", "className": "text-center", "orderable": false },
            { "data": "warningfault", "className": "text-center", "orderable": false },
            { "data": "payload", "className": "text-center", "orderable": false },
            { "data": "status", "className": "text-center", "orderable": false },
         ],
         "drawCallback": function ( settings ) {
            var api = this.api(), rows = api.rows( { page:'current' } ).nodes(), last = null;
            api.column(groupColumnHD, { page:'current' } ).data().each( function ( group, i ){
               if ( last !== group ) {
                  $(rows).eq( i ).before( '<tr class="group"><td colspan="5">'+group+'</td></tr>' );
                  last = group;
               }
            });
         }
      });

      $('#hd_search').keyup(function(){ tableHD.search($(this).val()).draw(); });

      $('#table_unit_hd tbody').on( 'click', 'tr.group', function (){
         var currentOrder = tableHD.order()[0];
         if ( currentOrder[0] === groupColumnHD && currentOrder[1] === 'asc' ){
            tableHD.order( [ groupColumnHD, 'desc' ] ).draw();
         } else {
            tableHD.order( [ groupColumnHD, 'asc' ] ).draw();
         }
      });
   });
</script>