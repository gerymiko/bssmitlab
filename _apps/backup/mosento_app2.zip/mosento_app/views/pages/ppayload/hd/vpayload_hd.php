<section class="content-header">
    <h1>Payload Unit <?=$detail_hd->nolambung;?></h1>
    <ol class="breadcrumb">
        <li><a href="<?=site_url();?>cpanel/syspanel">Home</a></li>
        <li>Payload</li>
        <li class="active"><?=$detail_hd->nolambung;?></li>
    </ol>
</section>
<div class="loading hidden" id="loading"></div>
<section class="content">
    <div class="row">
        <div class="col-md-3">
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title"></h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <div class="text-center">
                        <img src="<?=site_url();?>syslink/icon_hd" width="200" />
                    </div>
                </div>
                <div class="box-footer no-padding">
                    <ul class="nav nav-pills nav-stacked">
                        <li>
                            <a href="#">Excavator
                            <span class="pull-right"><b><?=$detail_hd->unit;?></b></span></a>
                        </li>
                        <li>
                            <a href="#">Serial Number 
                            <span class="pull-right"><b><?=$detail_hd->serialnumber;?></b></span></a>
                        </li>
                        <li>
                            <a href="#">Status
                            <span class="pull-right label <?=($detail_hd->status == 1) ? 'label-success' : 'label-danger';?>"><?=($detail_hd->status == 1) ? 'Active' : 'Non-Active';?></span></a>
                        </li>
                        <li>
                            <a href="#">Site
                            <span class="pull-right"><?=($site_unit->servername == null) ? 'Data not found' : $site_unit->servername;?></span></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="info-box" style="min-height: 55px;">
                <span class="info-box-icon bg-blue" style="height: 55px;width: 55px;font-size: 30px;line-height: 55px;"><i class="fas fa-calendar-check"></i></span>
                <div class="info-box-content" style="margin-left: 55px;">
                    <span class="info-box-text">LAST UPDATE DATA</span>
                    <span class="info-box-number f14"><?=($detail_hd->lastupdate == null ) ? "Data not updated" : date("d-m-Y H:i A", strtotime($detail_hd->lastupdate));?></span>
                </div>
            </div>
        </div>

        <div class="col-md-9">

            <div class="box box-primary ">
                <div class="box-header with-border">
                    <h3 class="box-title">Payload</h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <form id="form-filter-payload" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <label class="control-label">Pick date range</label>
                                <div class="input-group input-group">
                                    <input type="text" class="form-control required" id="date_range" name="date_range" placeholder="Choose date">
                                    <span class="input-group-btn">
                                        <button type="button" id="btn-filter-payload" class="btn btn-primary btn-flat">Search</button>
                                        <button class="btn btn-danger btn-flat" id="btn-reset-payload">Reset</button>
                                    </span>
                                </div><br>
                            </div>
                        </div>
                    </form>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Average Payload</label>
                                <input type="text" id="ave_payload" class="form-control input-sm" readonly>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Average BCM Payload</label>
                                <input type="text" id="ave_bcm_payload" class="form-control input-sm" readonly>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Min BCM Payload</label>
                                <input type="text" id="min_bcm_payload" class="form-control input-sm" readonly>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Max BCM Payload</label>
                                <input type="text" id="max_bcm_payload" class="form-control input-sm" readonly>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <span><em>* Value data for : <?=date('F, Y');?></em></span>
                        </div>
                    </div>
                    <br>
                    <div id="content_payload">
                        <table id="table_payload" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time (24 Hours)</th>
                                    <th>Payload</th>
                                    <th>BCM Payload</th>
                                    <th>NIK</th>
                                    <th>Driver</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div id="content_spayload" class="hidden">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs pull-right">
                                <li><a href="#chart_payload" data-toggle="tab">Chart</a></li>
                                <li class="active"><a href="#data_payload" data-toggle="tab">Data</a></li>
                                <li class="pull-left header"></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane" id="chart_payload">
                                    <div class="chart-responsive">
                                        <div class="chart" id="payload-chart" style="height: 450px;"></div>
                                    </div>
                                </div>
                                <div class="active tab-pane" id="data_payload">
                                    <table id="table_spayload" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                                        <thead class="bg-dark-gray">
                                            <tr>
                                                <th>#</th>
                                                <th>Date</th>
                                                <th>Time (24 Hours)</th>
                                                <th>Payload</th>
                                                <th>BCM Payload</th>
                                                <th>NIK</th>
                                                <th class="text-center">Driver</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Empty Drive Time</h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="content_emptydrivetime">
                        <table id="table_empty_drive_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time (24 Hours)</th>
                                    <th>Empty Drive Time (Minutes)</th>
                                    <th>NIK</th>
                                    <th>Driver</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div id="content_semptydrivetime" class="hidden">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs pull-right">
                                <li><a href="#chart_emptydrivetime" data-toggle="tab">Chart</a></li>
                                <li class="active"><a href="#data_emptydrivetime" data-toggle="tab">Data</a></li>
                                <li class="pull-left header"></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane" id="chart_emptydrivetime">
                                    <div class="chart-responsive">
                                        <div class="chart" id="emptydrivetime-chart" style="height: 450px;"></div>
                                    </div>
                                </div>
                                <div class="active tab-pane" id="data_emptydrivetime">
                                    <table id="table_sempty_drive_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                                        <thead class="bg-dark-gray">
                                            <tr>
                                                <th>#</th>
                                                <th>Date</th>
                                                <th>Time (24 Hours)</th>
                                                <th>Empty Drive Time (Minutes)</th>
                                                <th>NIK</th>
                                                <th>Driver</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Empty Drive Distance</h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="content_emptydrivedistance">
                        <table id="table_empty_drive_distance" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time (24 Hours)</th>
                                    <th>Empty Drive Distance (Km)</th>
                                    <th>NIK</th>
                                    <th>Driver</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div id="content_semptydrivedistance" class="hidden">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs pull-right">
                                <li><a href="#chart_emptydrivedistance" data-toggle="tab">Chart</a></li>
                                <li class="active"><a href="#data_emptydrivedistance" data-toggle="tab">Data</a></li>
                                <li class="pull-left header"></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane" id="chart_emptydrivedistance">
                                    <div class="chart-responsive">
                                        <div class="chart" id="emptydrivedistance-chart" style="height: 450px;"></div>
                                    </div>
                                </div>
                                <div class="active tab-pane" id="data_emptydrivedistance">
                                    <table id="table_sempty_drive_distance" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                                        <thead class="bg-dark-gray">
                                            <tr>
                                                <th>#</th>
                                                <th>Date</th>
                                                <th>Time (24 Hours)</th>
                                                <th>Empty Drive Distance (Km)</th>
                                                <th>NIK</th>
                                                <th>Driver</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Empty Stop Time</h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="content_emptystoptime">
                        <table id="table_empty_stop_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time (24 Hours)</th>
                                    <th>Empty Stop Time (Minutes)</th>
                                    <th>NIK</th>
                                    <th>Driver</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div id="content_semptystoptime" class="hidden">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs pull-right">
                                <li><a href="#chart_emptystoptime" data-toggle="tab">Chart</a></li>
                                <li class="active"><a href="#data_emptystoptime" data-toggle="tab">Data</a></li>
                                <li class="pull-left header"></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane" id="chart_emptystoptime">
                                    <div class="chart-responsive">
                                        <div class="chart" id="emptystoptime-chart" style="height: 450px;"></div>
                                    </div>
                                </div>
                                <div class="active tab-pane" id="data_emptystoptime">
                                    <table id="table_sempty_stop_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                                        <thead class="bg-dark-gray">
                                            <tr>
                                                <th>#</th>
                                                <th>Date</th>
                                                <th>Time (24 Hours)</th>
                                                <th>Empty Stop Time (Minutes)</th>
                                                <th>NIK</th>
                                                <th>Driver</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Loading Stop Time</h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="content_loadingstoptime">
                        <table id="table_loading_stop_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time (24 Hours)</th>
                                    <th>Loading Stop Time (Minutes)</th>
                                    <th>NIK</th>
                                    <th>Driver</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div id="content_sloadingstoptime" class="hidden">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs pull-right">
                                <li><a href="#chart_loadingstoptime" data-toggle="tab">Chart</a></li>
                                <li class="active"><a href="#data_loadingstoptime" data-toggle="tab">Data</a></li>
                                <li class="pull-left header"></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane" id="chart_loadingstoptime">
                                    <div class="chart-responsive">
                                        <div class="chart" id="loadingstoptime-chart" style="height: 450px;"></div>
                                    </div>
                                </div>
                                <div class="active tab-pane" id="data_loadingstoptime">
                                    <table id="table_sloading_stop_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                                        <thead class="bg-dark-gray">
                                            <tr>
                                                <th>#</th>
                                                <th>Date</th>
                                                <th>Time (24 Hours)</th>
                                                <th>Loading Stop Time (Minutes)</th>
                                                <th>NIK</th>
                                                <th>Driver</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Loaded Drive Time</h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="content_loadeddrivetime">
                        <table id="table_loaded_drive_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time (24 Hours)</th>
                                    <th>Loaded Drive Time (Minutes)</th>
                                    <th>NIK</th>
                                    <th>Driver</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div id="content_sloadeddrivetime" class="hidden">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs pull-right">
                                <li><a href="#chart_loaddeddrivetime" data-toggle="tab">Chart</a></li>
                                <li class="active"><a href="#data_loaddeddrivetime" data-toggle="tab">Data</a></li>
                                <li class="pull-left header"></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane" id="chart_loaddeddrivetime">
                                    <div class="chart-responsive">
                                        <div class="chart" id="loaddeddrivetime-chart" style="height: 450px;"></div>
                                    </div>
                                </div>
                                <div class="active tab-pane" id="data_loaddeddrivetime">
                                    <table id="table_sloaded_drive_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                                        <thead class="bg-dark-gray">
                                            <tr>
                                                <th>#</th>
                                                <th>Date</th>
                                                <th>Time (24 Hours)</th>
                                                <th>Loaded Drive Time (Minutes)</th>
                                                <th>NIK</th>
                                                <th>Driver</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Loaded Stop Time</h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <div id="content_loadedstoptime">
                        <table id="table_loaded_stop_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                            <thead class="bg-dark-gray">
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Time (24 Hours)</th>
                                    <th>Loaded Stop Time (Minutes)</th>
                                    <th>NIK</th>
                                    <th>Driver</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div id="content_sloadedstoptime" class="hidden">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs pull-right">
                                <li><a href="#chart_loadedstoptime" data-toggle="tab">Chart</a></li>
                                <li class="active"><a href="#data_loadedstoptime" data-toggle="tab">Data</a></li>
                                <li class="pull-left header"></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane" id="chart_loadedstoptime">
                                    <div class="chart-responsive">
                                        <div class="chart" id="loadedstoptime-chart" style="height: 450px;"></div>
                                    </div>
                                </div>
                                <div class="active tab-pane" id="data_loadedstoptime">
                                    <table id="table_sloaded_stop_time" class="table table-bordered table-hover nowrap" width="100%" cellspacing="0" scroll-collapse="false">
                                        <thead class="bg-dark-gray">
                                            <tr>
                                                <th>#</th>
                                                <th>Date</th>
                                                <th>Time (24 Hours)</th>
                                                <th>Loaded Stop Time (Minutes)</th>
                                                <th>NIK</th>
                                                <th>Driver</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<script type="text/javascript">
    $(document).ready(function (){
        $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){ 
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust(); 
            var data = $(this).data();
            if (data.chart !== undefined){ chart.validateSize(); }
        });

        $('#date_range').daterangepicker({ autoUpdateInput: false, locale: { cancelLabel: 'Clear' } });

        $('#date_range').on('apply.daterangepicker', function(ev, picker){
            $(this).val(picker.startDate.format('DD/MM/YYYY') + ' - ' + picker.endDate.format('DD/MM/YYYY'));
        });

        $('#date_range').on('cancel.daterangepicker', function(ev, picker){ $(this).val(''); });

        var table_payload = $('#table_payload').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "scrollX": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cpayload/hd/syspayload_hd/table_payload/<?=$this->encrypt->encode($detail_hd->serialnumber);?>',
                "type": 'POST',
                dataSrc: function ( data ){
                    $('#ave_payload').val(data.averagePay);
                    $('#ave_bcm_payload').val(data.averageBCM);
                    $('#min_bcm_payload').val(data.minBCM);
                    $('#max_bcm_payload').val(data.maxBCM);
                    return data.data;
                },
                error: function(data) {
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center" },
                { "data": "time", "className": "text-center", "orderable": false },
                { "data": "payload", "className": "text-center", "orderable": false },
                { "data": "bcm_payload", "className": "text-center", "orderable": false },
                { "data": "nik", "className": "text-center", "orderable": false },
                { "data": "name", "className": "text-center", "orderable": false },
            ],
        });

        var table_emptydrivetime = $('#table_empty_drive_time').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "scrollX": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cpayload/hd/syspayload_hd/table_empty_drive_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>',
                "type": 'POST',
                error: function(data){
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center", "orderable": false },
                { "data": "time", "className": "text-center", "orderable": false },
                { "data": "emptydrivetime", "className": "text-center", "orderable": false },
                { "data": "nik", "className": "text-center", "orderable": false },
                { "data": "name", "className": "text-center", "orderable": false },
            ],
        });

        var table_emptydrivedistance = $('#table_empty_drive_distance').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "scrollX": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cpayload/hd/syspayload_hd/table_empty_drive_distance/<?=$this->encrypt->encode($detail_hd->serialnumber);?>',
                "type": 'POST',
                error: function(data){
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center", "orderable": false },
                { "data": "time", "className": "text-center", "orderable": false },
                { "data": "emptydrivedistance", "className": "text-center", "orderable": false },
                { "data": "nik", "className": "text-center", "orderable": false },
                { "data": "name", "className": "text-center", "orderable": false },
            ],
        });

        var table_emptystoptime = $('#table_empty_stop_time').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "scrollX": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cpayload/hd/syspayload_hd/table_empty_stop_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>',
                "type": 'POST',
                error: function(data){
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center", "orderable": false },
                { "data": "time", "className": "text-center", "orderable": false },
                { "data": "emptystoptime", "className": "text-center", "orderable": false },
                { "data": "nik", "className": "text-center", "orderable": false },
                { "data": "name", "className": "text-center", "orderable": false },
            ],
        });

        var table_loadingstoptime = $('#table_loading_stop_time').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "scrollX": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cpayload/hd/syspayload_hd/table_loading_stop_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>',
                "type": 'POST',
                error: function(data){
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center", "orderable": false },
                { "data": "time", "className": "text-center", "orderable": false },
                { "data": "loadingstoptime", "className": "text-center", "orderable": false },
                { "data": "nik", "className": "text-center", "orderable": false },
                { "data": "name", "className": "text-center", "orderable": false },
            ],
        });

        var table_loadeddrivetime = $('#table_loaded_drive_time').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "scrollX": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cpayload/hd/syspayload_hd/table_loaded_drive_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>',
                "type": 'POST',
                error: function(data){
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center", "orderable": false },
                { "data": "time", "className": "text-center", "orderable": false },
                { "data": "loadeddrivetime", "className": "text-center", "orderable": false },
                { "data": "nik", "className": "text-center", "orderable": false },
                { "data": "name", "className": "text-center", "orderable": false },
            ],
        });

        var table_loadedstoptime = $('#table_loaded_stop_time').DataTable({
            "processing": true,
            "serverSide": true,
            "responsive": true,
            "scrollX": true,
            "order": [],
            "ajax": {
                "url": '<?=site_url()?>cpayload/hd/syspayload_hd/table_loaded_stop_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>',
                "type": 'POST',
                error: function(data){
                    swal("Oops!", "Failed to pull data. Reload page and try again", "error");
                }
            },
            "language": { 
                "processing": 
                '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
            },
            "columns": [
                { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                { "data": "date", "className": "text-center", "orderable": false },
                { "data": "time", "className": "text-center", "orderable": false },
                { "data": "loadedstoptime", "className": "text-center", "orderable": false },
                { "data": "nik", "className": "text-center", "orderable": false },
                { "data": "name", "className": "text-center", "orderable": false },
            ],
        });

        $('#btn-filter-payload').click(function(e){
            e.preventDefault();

            $('#loading').removeClass('hidden');

            if ($('#date_range').val() == '' || $('#date_range').val() == null){
                $('#loading').addClass('hidden');
                swal("Oops!", "Please choose date range first!", "error");
                return false;
            } else {
                $('#loading').addClass('hidden');

                var date_range = $('#date_range').val().split(' - '),
                    date_start = date_range[0],
                    date_end   = date_range[1],
                    date_start_new = date_start.replace(/\//g, '-'),
                    date_end_new   = date_end.replace(/\//g, '-');
                
                $('#content_payload').addClass('hidden');
                $('#content_spayload').removeClass('hidden');
                var table_spayload = $('#table_spayload').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "scrollX": true,
                    "bFilter": false,
                    "responsive": true,
                    "ordering": false,
                    "ajax": {
                        "url": '<?=site_url()?>cpayload/hd/syspayload_hd/search_table_payload/<?=$this->encrypt->encode($detail_hd->serialnumber);?>',
                        "type": 'POST',
                        "dataType": 'JSON',
                        "cache": false,
                        data : function ( data ){
                            data.date_start = date_start;
                            data.date_end   = date_end;
                            data[ 'csrf_token_mosento'] = '<?=$this->security->get_csrf_hash(); ?>';
                            return data;
                        },
                        dataSrc: function ( data ){
                            $('#ave_payload').val(data.averagePay);
                            $('#ave_bcm_payload').val(data.averageBCM);
                            $('#min_bcm_payload').val(data.minBCM);
                            $('#max_bcm_payload').val(data.maxBCM);
                            return data.data;
                        },
                        dataFilter:function(response){ return response; },
                    },
                    "language": { 
                        "processing": 
                        '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
                        "sInfoFiltered": ""
                    },
                    "columns": [
                        { "data": "no", "className": "text-center"},
                        { "data": "date","className": "text-center"},
                        { "data": "time","className": "text-center"},
                        { "data": "payload","className": "text-center"},
                        { "data": "bcm_payload","className": "text-center"},
                        { "data": "nik","className": "text-center"},
                        { "data": "name","className": "text-left"},
                    ],
                });

                 var chart = am4core.create("payload-chart", am4charts.XYChart);
                 chart.dateFormatter.inputDateFormat = "i";
                 chart.responsive.enabled = true;
                 chart.preloader.disabled = true;
                 var indicator;
                 function showIndicator(){
                     if (indicator){ indicator.show(); } 
                     else {
                         indicator = chart.tooltipContainer.createChild(am4core.Container);
                         indicator.background.fill = am4core.color("#fff");
                         indicator.background.fillOpacity = 1.00;
                         indicator.width = am4core.percent(100);
                         indicator.height = am4core.percent(100);
                         var indicatorLabel = indicator.createChild(am4core.Label);
                         indicatorLabel.text = "No data...";
                         indicatorLabel.align = "center";
                         indicatorLabel.valign = "middle";
                         indicatorLabel.fontSize = 20;
                     }
                 }
                 function hideIndicator(){ indicator.hide(); }
                 chart.events.on("beforevalidated", function(ev){
                     if (ev.target.data.length == 0){ showIndicator(); } 
                     else if (indicator) { hideIndicator(); }
                 });
                 chart.dataSource.url = '<?=site_url();?>cpayload/hd/syspayload_hd/chart_payload/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new ;

                 var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
                 dateAxis.renderer.grid.template.disabled = true;
                 dateAxis.baseInterval = { "timeUnit": "minute" };
                 dateAxis.tooltipDateFormat = "hh:mm a, d MMMM";

                 var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
                 valueAxis.title.text = "Payload";

                 var series = chart.series.push(new am4charts.LineSeries());
                 series.dataFields.dateX = "date";
                 series.dataFields.valueY = "payload";
                 series.dataFields.bcmValueY = "bcm";
                 series.dataFields.nikValueY = "nik";
                 series.dataFields.nameValueY = "name";
                 series.tooltipText = "Payload: [bold]{valueY}[/]\nBCM: [bold]{bcmValueY}[/]\nNIK: [bold]{nikValueY}[/]\nDriver: [bold]{nameValueY}[/]";
                 series.strokeWidth = 2;
                 series.name = "Payload";

                 var bullet = series.bullets.push(new am4charts.CircleBullet());
                 bullet.circle.stroke = am4core.color("#fff");
                 bullet.circle.strokeWidth = 2;
                 bullet.circle.radius = 3;
                 bullet.circle.fill = am4core.color("#1883E9");

                 var hoverState = bullet.states.create("hover");
                 hoverState.properties.scale = 1.7;

                 chart.legend = new am4charts.Legend();
                 chart.cursor = new am4charts.XYCursor();
                 chart.events.on("beforedatavalidated", function(ev){
                     chart.data.sort(function(a, b){ return (new Date(a.date)) - (new Date(b.date)); });
                 });

                 chart.scrollbarX = new am4charts.XYChartScrollbar();
                 chart.scrollbarX.series.push(series);

                 chart.cursor = new am4charts.XYCursor();
                 chart.cursor.behavior = "panXY";
                 chart.cursor.xAxis = dateAxis;
                 chart.cursor.snapToSeries = series;
                 chart.maskBullets = false;

                $('#content_emptydrivetime').addClass('hidden');
                $('#content_semptydrivetime').removeClass('hidden');
                var table_semptydrivetime = $('#table_sempty_drive_time').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "responsive": true,
                    "scrollX": true,
                    "bFilter": false,
                    "ordering": false,
                    "ajax": {
                        "url": '<?=site_url()?>cpayload/hd/syspayload_hd/search_table_empty_drive_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new,
                        "type": 'POST',
                        data : function ( data ){
                            data[ 'csrf_token_mosento'] = '<?=$this->security->get_csrf_hash(); ?>';
                            return data;
                        },
                        dataFilter:function(response){ return response; },
                    },
                    "language": { 
                        "processing": 
                        '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
                    },
                    "columns": [
                        { "data": "no", "className": "text-center" },
                        { "data": "date", "className": "text-center" },
                        { "data": "time", "className": "text-center" },
                        { "data": "emptydrivetime", "className": "text-center" },
                        { "data": "nik", "className": "text-center" },
                        { "data": "name", "className": "text-center" },
                    ],
                });

                 var chart2 = am4core.create("emptydrivetime-chart", am4charts.XYChart);
                 chart2.dateFormatter.inputDateFormat = "i";
                 chart2.responsive.enabled = true;
                 chart2.preloader.disabled = true;
                 var indicator2;
                 function showIndicator(){
                     if (indicator2){ indicator2.show(); } 
                     else {
                         indicator2 = chart3.tooltipContainer.createChild(am4core.Container);
                         indicator2.background.fill = am4core.color("#fff");
                         indicator2.background.fillOpacity = 1.00;
                         indicator2.width = am4core.percent(100);
                         indicator2.height = am4core.percent(100);
                         var indicatorLabel2 = indicator2.createChild(am4core.Label);
                         indicatorLabel2.text = "No data...";
                         indicatorLabel2.align = "center";
                         indicatorLabel2.valign = "middle";
                         indicatorLabel2.fontSize = 20;
                     }
                 }
                 function hideIndicator(){ indicator2.hide(); }
                 chart2.events.on("beforevalidated", function(ev){
                     if (ev.target.data.length == 0){ showIndicator(); } 
                     else if (indicator2) { hideIndicator(); }
                 });
                 chart2.dataSource.url = '<?=site_url();?>cpayload/hd/syspayload_hd/chart_emptydrivetime/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new ;

                 var dateAxis2 = chart2.xAxes.push(new am4charts.DateAxis());
                 dateAxis2.renderer.grid.template.disabled = true;
                 dateAxis2.baseInterval = { "timeUnit": "minute" };
                 dateAxis2.tooltipDateFormat = "hh:mm a, d MMMM";

                 var valueAxis2 = chart2.yAxes.push(new am4charts.ValueAxis());
                 valueAxis2.title.text = "Empty Drive Time (Minutes)";

                 var series2 = chart2.series.push(new am4charts.LineSeries());
                 series2.dataFields.dateX = "date";
                 series2.dataFields.valueY = "emptydrivetime";
                 series2.dataFields.nikValueY = "nik";
                 series2.dataFields.nameValueY = "name";
                 series2.tooltipText = "Empty Drive Time: [bold]{valueY}[/]\nNIK: [bold]{nikValueY}[/]\nDriver: [bold]{nameValueY}[/]";
                 series2.strokeWidth = 2;
                 series2.name = "Empty Drive Time (Minutes)";

                 var bullet2 = series2.bullets.push(new am4charts.CircleBullet());
                 bullet2.circle.stroke = am4core.color("#fff");
                 bullet2.circle.strokeWidth = 2;
                 bullet2.circle.radius = 3;
                 bullet2.circle.fill = am4core.color("#1883E9");

                 var hoverState2 = bullet2.states.create("hover");
                 hoverState2.properties.scale = 1.7;

                 chart2.legend = new am4charts.Legend();
                 chart2.cursor = new am4charts.XYCursor();
                 chart2.events.on("beforedatavalidated", function(ev){
                     chart2.data.sort(function(a, b){ return (new Date(a.date)) - (new Date(b.date)); });
                 });

                 chart2.scrollbarX = new am4charts.XYChartScrollbar();
                 chart2.scrollbarX.series.push(series2);

                 chart2.cursor = new am4charts.XYCursor();
                 chart2.cursor.behavior = "panXY";
                 chart2.cursor.xAxis = dateAxis2;
                 chart2.cursor.snapToSeries = series2;
                 chart2.maskBullets = false;
                
                $('#content_emptydrivedistance').addClass('hidden');
                $('#content_semptydrivedistance').removeClass('hidden');
                var table_semptydrivedistance = $('#table_sempty_drive_distance').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "responsive": true,
                    "scrollX": true,
                    "bFilter": false,
                    "ordering": false,
                    "ajax": {
                        "url": '<?=site_url()?>cpayload/hd/syspayload_hd/search_table_empty_drive_distance/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new,
                        "type": 'POST',
                        data : function ( data ){
                            data[ 'csrf_token_mosento'] = '<?=$this->security->get_csrf_hash(); ?>';
                            return data;
                        },
                        dataFilter:function(response){ return response; },
                    },
                    "language": { 
                        "processing": 
                        '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
                    },
                    "columns": [
                        { "data": "no", "className": "text-center" },
                        { "data": "date", "className": "text-center" },
                        { "data": "time", "className": "text-center" },
                        { "data": "emptydrivedistance", "className": "text-center" },
                        { "data": "nik", "className": "text-center" },
                        { "data": "name", "className": "text-center" },
                    ],
                });

                 var chart3 = am4core.create("emptydrivedistance-chart", am4charts.XYChart);
                 chart3.dateFormatter.inputDateFormat = "i";
                 chart3.responsive.enabled = true;
                 chart3.preloader.disabled = true;
                 var indicator3;
                 function showIndicator(){
                     if (indicator3){ indicator3.show(); } 
                     else {
                         indicator3 = chart3.tooltipContainer.createChild(am4core.Container);
                         indicator3.background.fill = am4core.color("#fff");
                         indicator3.background.fillOpacity = 1.00;
                         indicator3.width = am4core.percent(100);
                         indicator3.height = am4core.percent(100);
                         var indicatorLabel3 = indicator3.createChild(am4core.Label);
                         indicatorLabel3.text = "No data...";
                         indicatorLabel3.align = "center";
                         indicatorLabel3.valign = "middle";
                         indicatorLabel3.fontSize = 20;
                     }
                 }
                 function hideIndicator(){ indicator3.hide(); }
                 chart3.events.on("beforevalidated", function(ev){
                     if (ev.target.data.length == 0){ showIndicator(); } 
                     else if (indicator3) { hideIndicator(); }
                 });
                 chart3.dataSource.url = '<?=site_url();?>cpayload/hd/syspayload_hd/chart_emptydrivedistance/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new ;

                 var dateAxis3 = chart3.xAxes.push(new am4charts.DateAxis());
                 dateAxis3.renderer.grid.template.disabled = true;
                 dateAxis3.baseInterval = { "timeUnit": "minute" };
                 dateAxis3.tooltipDateFormat = "hh:mm a, d MMMM";

                 var valueAxis3 = chart3.yAxes.push(new am4charts.ValueAxis());
                 valueAxis3.title.text = "Empty Drive Distance (KM/h)";

                 var series3 = chart3.series.push(new am4charts.LineSeries());
                 series3.dataFields.dateX = "date";
                 series3.dataFields.valueY = "emptydrivedistance";
                 series3.dataFields.nikValueY = "nik";
                 series3.dataFields.nameValueY = "name";
                 series3.tooltipText = "Empty Drive Distance: [bold]{valueY}[/]\nNIK: [bold]{nikValueY}[/]\nDriver: [bold]{nameValueY}[/]";
                 series3.strokeWidth = 2;
                 series3.name = "Empty Drive Distance (KM/h)";

                 var bullet3 = series3.bullets.push(new am4charts.CircleBullet());
                 bullet3.circle.stroke = am4core.color("#fff");
                 bullet3.circle.strokeWidth = 2;
                 bullet3.circle.radius = 3;
                 bullet3.circle.fill = am4core.color("#1883E9");

                 var hoverState3 = bullet3.states.create("hover");
                 hoverState3.properties.scale = 1.7;

                 chart3.legend = new am4charts.Legend();
                 chart3.cursor = new am4charts.XYCursor();
                 chart3.events.on("beforedatavalidated", function(ev){
                     chart3.data.sort(function(a, b){ return (new Date(a.date)) - (new Date(b.date)); });
                 });

                 chart3.scrollbarX = new am4charts.XYChartScrollbar();
                 chart3.scrollbarX.series.push(series3);

                 chart3.cursor = new am4charts.XYCursor();
                 chart3.cursor.behavior = "panXY";
                 chart3.cursor.xAxis = dateAxis3;
                 chart3.cursor.snapToSeries = series3;
                 chart3.maskBullets = false;

                $('#content_emptystoptime').addClass('hidden');
                $('#content_semptystoptime').removeClass('hidden');
                var table_semptystoptime = $('#table_sempty_stop_time').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "responsive": true,
                    "scrollX": true,
                    "bFilter": false,
                    "ordering": false,
                    "ajax": {
                        "url": '<?=site_url()?>cpayload/hd/syspayload_hd/search_table_empty_stop_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new,
                        "type": 'POST',
                        data : function ( data ){
                            data[ 'csrf_token_mosento'] = '<?=$this->security->get_csrf_hash(); ?>';
                            return data;
                        },
                        dataFilter:function(response){ return response; },
                    },
                    "language": { 
                        "processing": 
                        '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
                    },
                    "columns": [
                        { "data": "no", "className": "text-center" },
                        { "data": "date", "className": "text-center" },
                        { "data": "time", "className": "text-center" },
                        { "data": "emptystoptime", "className": "text-center" },
                        { "data": "nik", "className": "text-center" },
                        { "data": "name", "className": "text-center" },
                    ],
                });

                 var chart4 = am4core.create("emptystoptime-chart", am4charts.XYChart);
                 chart4.dateFormatter.inputDateFormat = "i";
                 chart4.responsive.enabled = true;
                 chart4.preloader.disabled = true;
                 var indicator4;
                 function showIndicator(){
                     if (indicator4){ indicator4.show(); } 
                     else {
                         indicator4 = chart4.tooltipContainer.createChild(am4core.Container);
                         indicator4.background.fill = am4core.color("#fff");
                         indicator4.background.fillOpacity = 1.00;
                         indicator4.width = am4core.percent(100);
                         indicator4.height = am4core.percent(100);
                         var indicatorLabel4 = indicator4.createChild(am4core.Label);
                         indicatorLabel4.text = "No data...";
                         indicatorLabel4.align = "center";
                         indicatorLabel4.valign = "middle";
                         indicatorLabel4.fontSize = 20;
                     }
                 }
                 function hideIndicator(){ indicator4.hide(); }
                 chart4.events.on("beforevalidated", function(ev){
                     if (ev.target.data.length == 0){ showIndicator(); } 
                     else if (indicator4) { hideIndicator(); }
                 });
                 chart4.dataSource.url = '<?=site_url();?>cpayload/hd/syspayload_hd/chart_emptystoptime/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new ;

                 var dateAxis4 = chart4.xAxes.push(new am4charts.DateAxis());
                 dateAxis4.renderer.grid.template.disabled = true;
                 dateAxis4.baseInterval = { "timeUnit": "minute" };
                 dateAxis4.tooltipDateFormat = "hh:mm a, d MMMM";

                 var valueAxis4 = chart4.yAxes.push(new am4charts.ValueAxis());
                 valueAxis4.title.text = "Empty Stop Time (Minutes)";

                 var series4 = chart4.series.push(new am4charts.LineSeries());
                 series4.dataFields.dateX = "date";
                 series4.dataFields.valueY = "emptystoptime";
                 series4.dataFields.nikValueY = "nik";
                 series4.dataFields.nameValueY = "name";
                 series4.tooltipText = "Empty Stop Time: [bold]{valueY}[/]\nNIK: [bold]{nikValueY}[/]\nDriver: [bold]{nameValueY}[/]";
                 series4.strokeWidth = 2;
                 series4.name = "Empty Stop Time (Minutes)";

                 var bullet4 = series4.bullets.push(new am4charts.CircleBullet());
                 bullet4.circle.stroke = am4core.color("#fff");
                 bullet4.circle.strokeWidth = 2;
                 bullet4.circle.radius = 3;
                 bullet4.circle.fill = am4core.color("#1883E9");

                 var hoverState4 = bullet4.states.create("hover");
                 hoverState4.properties.scale = 1.7;

                 chart4.legend = new am4charts.Legend();
                 chart4.cursor = new am4charts.XYCursor();
                 chart4.events.on("beforedatavalidated", function(ev){
                     chart4.data.sort(function(a, b){ return (new Date(a.date)) - (new Date(b.date)); });
                 });

                 chart4.scrollbarX = new am4charts.XYChartScrollbar();
                 chart4.scrollbarX.series.push(series4);

                 chart4.cursor = new am4charts.XYCursor();
                 chart4.cursor.behavior = "panXY";
                 chart4.cursor.xAxis = dateAxis4;
                 chart4.cursor.snapToSeries = series4;
                 chart4.maskBullets = false;

                $('#content_loadingstoptime').addClass('hidden');
                $('#content_sloadingstoptime').removeClass('hidden');
                var table_sloadingstoptime = $('#table_sloading_stop_time').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "responsive": true,
                    "scrollX": true,
                    "bFilter": false,
                    "ordering": false,
                    "ajax": {
                        "url": '<?=site_url()?>cpayload/hd/syspayload_hd/search_table_loading_stop_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new,
                        "type": 'POST',
                        data : function ( data ){
                            data[ 'csrf_token_mosento'] = '<?=$this->security->get_csrf_hash(); ?>';
                            return data;
                        },
                        dataFilter:function(response){ return response; },
                    },
                    "language": { 
                        "processing": 
                        '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
                    },
                    "columns": [
                        { "data": "no", "className": "text-center", "searchable": false, "orderable": false },
                        { "data": "date", "className": "text-center", "orderable": false },
                        { "data": "time", "className": "text-center", "orderable": false },
                        { "data": "loadingstoptime", "className": "text-center", "orderable": false },
                        { "data": "nik", "className": "text-center", "orderable": false },
                        { "data": "name", "className": "text-center", "orderable": false },
                    ],
                });

                 var chart5 = am4core.create("loadingstoptime-chart", am4charts.XYChart);
                 chart5.dateFormatter.inputDateFormat = "i";
                 chart5.responsive.enabled = true;
                 chart5.preloader.disabled = true;
                 var indicator5;
                 function showIndicator(){
                     if (indicator5){ indicator5.show(); } 
                     else {
                         indicator5 = chart5.tooltipContainer.createChild(am4core.Container);
                         indicator5.background.fill = am4core.color("#fff");
                         indicator5.background.fillOpacity = 1.00;
                         indicator5.width = am4core.percent(100);
                         indicator5.height = am4core.percent(100);
                         var indicatorLabel5 = indicator5.createChild(am4core.Label);
                         indicatorLabel5.text = "No data...";
                         indicatorLabel5.align = "center";
                         indicatorLabel5.valign = "middle";
                         indicatorLabel5.fontSize = 20;
                     }
                 }
                 function hideIndicator(){ indicator5.hide(); }
                 chart5.events.on("beforevalidated", function(ev){
                     if (ev.target.data.length == 0){ showIndicator(); } 
                     else if (indicator5) { hideIndicator(); }
                 });
                 chart5.dataSource.url = '<?=site_url();?>cpayload/hd/syspayload_hd/chart_loadingstoptime/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new ;

                 var dateAxis5 = chart5.xAxes.push(new am4charts.DateAxis());
                 dateAxis5.renderer.grid.template.disabled = true;
                 dateAxis5.baseInterval = { "timeUnit": "minute" };
                 dateAxis5.tooltipDateFormat = "hh:mm a, d MMMM";

                 var valueAxis5 = chart5.yAxes.push(new am4charts.ValueAxis());
                 valueAxis5.title.text = "Loading Stop Time (Minutes)";

                 var series5 = chart5.series.push(new am4charts.LineSeries());
                 series5.dataFields.dateX = "date";
                 series5.dataFields.valueY = "loadingstoptime";
                 series5.dataFields.nikValueY = "nik";
                 series5.dataFields.nameValueY = "name";
                 series5.tooltipText = "Loading Stop Time: [bold]{valueY}[/]\nNIK: [bold]{nikValueY}[/]\nDriver: [bold]{nameValueY}[/]";
                 series5.strokeWidth = 2;
                 series5.name = "Loading Stop Time (Minutes)";

                 var bullet5 = series5.bullets.push(new am4charts.CircleBullet());
                 bullet5.circle.stroke = am4core.color("#fff");
                 bullet5.circle.strokeWidth = 2;
                 bullet5.circle.radius = 3;
                 bullet5.circle.fill = am4core.color("#1883E9");

                 var hoverState5 = bullet5.states.create("hover");
                 hoverState5.properties.scale = 1.7;

                 chart5.legend = new am4charts.Legend();
                 chart5.cursor = new am4charts.XYCursor();
                 chart5.events.on("beforedatavalidated", function(ev){
                     chart5.data.sort(function(a, b){ return (new Date(a.date)) - (new Date(b.date)); });
                 });

                 chart5.scrollbarX = new am4charts.XYChartScrollbar();
                 chart5.scrollbarX.series.push(series5);

                 chart5.cursor = new am4charts.XYCursor();
                 chart5.cursor.behavior = "panXY";
                 chart5.cursor.xAxis = dateAxis5;
                 chart5.cursor.snapToSeries = series5;
                 chart5.maskBullets = false;
            }

            $('#content_loadeddrivetime').addClass('hidden');
            $('#content_sloadeddrivetime').removeClass('hidden');
            var table_loadeddrivetime = $('#table_sloaded_drive_time').DataTable({
                "processing": true,
                "serverSide": true,
                "responsive": true,
                "scrollX": true,
                "bFilter": false,
                "ordering": false,
                "ajax": {
                    "url": '<?=site_url()?>cpayload/hd/syspayload_hd/search_table_loaded_drive_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new,
                    "type": 'POST',
                    data : function ( data ){
                        data[ 'csrf_token_mosento'] = '<?=$this->security->get_csrf_hash(); ?>';
                        return data;
                    },
                    dataFilter:function(response){ return response; },
                },
                "language": { 
                    "processing": 
                    '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
                },
                "columns": [
                    { "data": "no", "className": "text-center" },
                    { "data": "date", "className": "text-center" },
                    { "data": "time", "className": "text-center" },
                    { "data": "loadeddrivetime", "className": "text-center" },
                    { "data": "nik", "className": "text-center" },
                    { "data": "name", "className": "text-center" },
                ],
            });

             var chart6 = am4core.create("loaddeddrivetime-chart", am4charts.XYChart);
             chart6.dateFormatter.inputDateFormat = "i";
             chart6.responsive.enabled = true;
             chart6.preloader.disabled = true;
             var indicator6;
             function showIndicator(){
                 if (indicator6){ indicator6.show(); } 
                 else {
                     indicator6 = chart6.tooltipContainer.createChild(am4core.Container);
                     indicator6.background.fill = am4core.color("#fff");
                     indicator6.background.fillOpacity = 1.00;
                     indicator6.width = am4core.percent(100);
                     indicator6.height = am4core.percent(100);
                     var indicatorLabel6 = indicator6.createChild(am4core.Label);
                     indicatorLabel6.text = "No data...";
                     indicatorLabel6.align = "center";
                     indicatorLabel6.valign = "middle";
                     indicatorLabel6.fontSize = 20;
                 }
             }
             function hideIndicator(){ indicator6.hide(); }
             chart6.events.on("beforevalidated", function(ev){
                 if (ev.target.data.length == 0){ showIndicator(); } 
                 else if (indicator6) { hideIndicator(); }
             });
             chart6.dataSource.url = '<?=site_url();?>cpayload/hd/syspayload_hd/chart_loadeddrivetime/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new ;

             var dateAxis6 = chart6.xAxes.push(new am4charts.DateAxis());
             dateAxis6.renderer.grid.template.disabled = true;
             dateAxis6.baseInterval = { "timeUnit": "minute" };
             dateAxis6.tooltipDateFormat = "hh:mm a, d MMMM";

             var valueAxis6 = chart6.yAxes.push(new am4charts.ValueAxis());
             valueAxis6.title.text = "Loaded Drive Time (Minutes)";

             var series6 = chart6.series.push(new am4charts.LineSeries());
             series6.dataFields.dateX = "date";
             series6.dataFields.valueY = "loadeddrivetime";
             series6.dataFields.nikValueY = "nik";
             series6.dataFields.nameValueY = "name";
             series6.tooltipText = "Loaded Drive Time: [bold]{valueY}[/]\nNIK: [bold]{nikValueY}[/]\nDriver: [bold]{nameValueY}[/]";
             series6.strokeWidth = 2;
             series6.name = "Loaded Drive Time (Minutes)";

             var bullet6 = series6.bullets.push(new am4charts.CircleBullet());
             bullet6.circle.stroke = am4core.color("#fff");
             bullet6.circle.strokeWidth = 2;
             bullet6.circle.radius = 3;
             bullet6.circle.fill = am4core.color("#1883E9");

             var hoverState6 = bullet6.states.create("hover");
             hoverState6.properties.scale = 1.7;

             chart6.legend = new am4charts.Legend();
             chart6.cursor = new am4charts.XYCursor();
             chart6.events.on("beforedatavalidated", function(ev){
                 chart6.data.sort(function(a, b){ return (new Date(a.date)) - (new Date(b.date)); });
             });

             chart6.scrollbarX = new am4charts.XYChartScrollbar();
             chart6.scrollbarX.series.push(series6);

             chart6.cursor = new am4charts.XYCursor();
             chart6.cursor.behavior = "panXY";
             chart6.cursor.xAxis = dateAxis6;
             chart6.cursor.snapToSeries = series6;
             chart6.maskBullets = false;

            $('#content_loadedstoptime').addClass('hidden');
            $('#content_sloadedstoptime').removeClass('hidden');
            var table_sloadedstoptime = $('#table_sloaded_stop_time').DataTable({
                "processing": true,
                "serverSide": true,
                "responsive": true,
                "scrollX": true,
                "ordering": false,
                "ajax": {
                    "url": '<?=site_url()?>cpayload/hd/syspayload_hd/search_table_loaded_stop_time/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new,
                    "type": 'POST',
                    data : function ( data ){
                        data[ 'csrf_token_mosento'] = '<?=$this->security->get_csrf_hash(); ?>';
                        return data;
                    },
                    dataFilter:function(response){ return response; },
                },
                "language": { 
                    "processing": 
                    '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
                },
                "columns": [
                    { "data": "no", "className": "text-center" },
                    { "data": "date", "className": "text-center" },
                    { "data": "time", "className": "text-center" },
                    { "data": "loadedstoptime", "className": "text-center" },
                    { "data": "nik", "className": "text-center" },
                    { "data": "name", "className": "text-center" },
                ],
            });

             var chart7 = am4core.create("loadedstoptime-chart", am4charts.XYChart);
             chart7.dateFormatter.inputDateFormat = "i";
             chart7.responsive.enabled = true;
             chart7.preloader.disabled = true;
             var indicator7;
             function showIndicator(){
                 if (indicator7){ indicator7.show(); } 
                 else {
                     indicator7 = chart7.tooltipContainer.createChild(am4core.Container);
                     indicator7.background.fill = am4core.color("#fff");
                     indicator7.background.fillOpacity = 1.00;
                     indicator7.width = am4core.percent(100);
                     indicator7.height = am4core.percent(100);
                     var indicatorLabel7 = indicator7.createChild(am4core.Label);
                     indicatorLabel7.text = "No data...";
                     indicatorLabel7.align = "center";
                     indicatorLabel7.valign = "middle";
                     indicatorLabel7.fontSize = 20;
                 }
             }
             function hideIndicator(){ indicator7.hide(); }
             chart7.events.on("beforevalidated", function(ev){
                 if (ev.target.data.length == 0){ showIndicator(); } 
                 else if (indicator7) { hideIndicator(); }
             });
             chart7.dataSource.url = '<?=site_url();?>cpayload/hd/syspayload_hd/chart_loadedstoptime/<?=$this->encrypt->encode($detail_hd->serialnumber);?>/'+date_start_new+'/'+date_end_new ;

             var dateAxis7 = chart7.xAxes.push(new am4charts.DateAxis());
             dateAxis7.renderer.grid.template.disabled = true;
             dateAxis7.baseInterval = { "timeUnit": "minute" };
             dateAxis7.tooltipDateFormat = "hh:mm a, d MMMM";

             var valueAxis7 = chart7.yAxes.push(new am4charts.ValueAxis());
             valueAxis7.title.text = "Loaded Stop Time (Minutes)";

             var series7 = chart7.series.push(new am4charts.LineSeries());
             series7.dataFields.dateX = "date";
             series7.dataFields.valueY = "loadedstoptime";
             series7.dataFields.nikValueY = "nik";
             series7.dataFields.nameValueY = "name";
             series7.tooltipText = "Loaded Stop Time: [bold]{valueY}[/]\nNIK: [bold]{nikValueY}[/]\nDriver: [bold]{nameValueY}[/]";
             series7.strokeWidth = 2;
             series7.name = "Loaded Stop Time (Minutes)";

             var bullet7 = series7.bullets.push(new am4charts.CircleBullet());
             bullet7.circle.stroke = am4core.color("#fff");
             bullet7.circle.strokeWidth = 2;
             bullet7.circle.radius = 3;
             bullet7.circle.fill = am4core.color("#1883E9");

             var hoverState7 = bullet7.states.create("hover");
             hoverState7.properties.scale = 1.7;

             chart7.legend = new am4charts.Legend();
             chart7.cursor = new am4charts.XYCursor();
             chart7.events.on("beforedatavalidated", function(ev){
                 chart7.data.sort(function(a, b){ return (new Date(a.date)) - (new Date(b.date)); });
             });

             chart7.scrollbarX = new am4charts.XYChartScrollbar();
             chart7.scrollbarX.series.push(series7);

             chart7.cursor = new am4charts.XYCursor();
             chart7.cursor.behavior = "panXY";
             chart7.cursor.xAxis = dateAxis7;
             chart7.cursor.snapToSeries = series7;
             chart7.maskBullets = false;

        });

        $('#btn-reset-payload').click(function(e) {
            e.preventDefault();

            $('#form-filter-payload')[0].reset();

            $('#table_spayload').DataTable().destroy();
            $('#table_sempty_drive_time').DataTable().destroy();
            $('#table_sempty_drive_distance').DataTable().destroy();
            $('#table_sempty_stop_time').DataTable().destroy();
            $('#table_sloading_stop_time').DataTable().destroy();
            $('#table_sloaded_drive_time').DataTable().destroy();
            $('#table_sloaded_stop_time').DataTable().destroy();

            $('#content_payload').removeClass('hidden');
            $('#content_emptydrivetime').removeClass('hidden');
            $('#content_emptydrivedistance').removeClass('hidden');
            $('#content_emptystoptime').removeClass('hidden');
            $('#content_loadingstoptime').removeClass('hidden');
            $('#content_loadeddrivetime').removeClass('hidden');
            $('#content_loadedstoptime').removeClass('hidden');

            $('#content_spayload').addClass('hidden');
            $('#content_semptydrivetime').addClass('hidden');
            $('#content_semptydrivedistance').addClass('hidden');
            $('#content_semptystoptime').addClass('hidden');
            $('#content_sloadingstoptime').addClass('hidden');
            $('#content_sloadeddrivetime').addClass('hidden');
            $('#content_sloadedstoptime').addClass('hidden');
            
            $('#table_payload').DataTable().ajax.reload();
            $('#table_empty_drive_time').DataTable().ajax.reload();
            $('#table_empty_drive_distance').DataTable().ajax.reload();
            $('#table_empty_stop_time').DataTable().ajax.reload();
            $('#table_loading_stop_time').DataTable().ajax.reload();
            $('#table_loaded_drive_time').DataTable().ajax.reload();
            $('#table_loaded_stop_time').DataTable().ajax.reload();
        });


    });
</script>