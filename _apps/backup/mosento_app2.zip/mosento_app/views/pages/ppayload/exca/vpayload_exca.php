<section class="content-header">
    <h1>Payload Unit <?=$detail_exca->nolambung;?></h1>
    <ol class="breadcrumb">
        <li><a href="<?=site_url();?>cpanel/syspanel">Home</a></li>
        <li>Payload</li>
        <li class="active"><?=$detail_exca->nolambung;?></li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-3">
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title"></h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <div class="text-center">
                        <img src="<?=site_url();?>syslink/icon_exca" width="200" />
                    </div>
                </div>
                <div class="box-footer no-padding">
                    <ul class="nav nav-pills nav-stacked">
                        <li>
                            <a href="#">Excavator
                            <span class="pull-right"><b><?=$detail_exca->unit;?></b></span></a>
                        </li>
                        <li>
                            <a href="#">Serial Number 
                            <span class="pull-right"><b><?=$detail_exca->serialnumber;?></b></span></a>
                        </li>
                        <li>
                            <a href="#">Status
                            <span class="pull-right label <?=($detail_exca->status == 1) ? 'label-success' : 'label-danger';?>"><?=($detail_exca->status == 1) ? 'Active' : 'Non-Active';?></span></a>
                        </li>
                        <li>
                            <a href="#">Site
                            <span class="pull-right"><?=($site_unit->servername == null) ? 'Data not found' : $site_unit->servername;?></span></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="far fa-calendar-check"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">LAST UPDATE DATA</span>
                  <span class="info-box-number"><?=($detail_exca->lastupdate == null ) ? "Data not updated" : date("d-m-Y H:i A", strtotime($detail_exca->lastupdate));?></span>
                </div>
            </div>
        </div>
    </div>
</section>