<?php defined('BASEPATH') OR exit('No direct script access allowed');

	class Mod_payload_exca extends CI_Model {

		function __construct() {
	        parent::__construct();
	        $this->load->database();
	    }

	    private static function pregReps($string) { 
	        $result = preg_replace('/[^a-zA-Z0-9 _.]/','', $string);
	        return $result;
	    }

	    private static function pregRepn($number) { 
	        $result = preg_replace('/[^0-9]/','', $number);
	        return $result;
	    }

	    function get_detail_exca($serialnumber){
	    	$datax = array( 'serialnumber' => $this->pregReps($serialnumber) );
	    	$query = $this->db->select('unit, type_unit, serialnumber, nolambung, lastupdate, status')
	    				->from('unit')
	    				->where($datax)
	    				->get();
	    	if($query->num_rows() > 0 ){
	            return $query->row(); 
	    	} else { return false; }
	    }

	    function get_unit_exca($serialnumber){
	    	$datax = array( 'a.serialnumber' => $this->pregReps($serialnumber) );
	    	$query = $this->db->select('b.servername, a.serialnumber')
	    				->from('unit a')
	    				->join('trend b', 'a.nolambung = b.unit', 'left')
	    				->where($datax)
	    				->group_by('b.servername, a.unit, a.serialnumber, a.nolambung')
	    				->limit(1)
	    				->get();
	    	if($query->num_rows() > 0 ){
	            return $query->row(); 
	    	} else { return false; }
	    }
	}
?>