<section class="content-header">
   <h1>Dashboard</h1>
   <ol class="breadcrumb">
      <li><a href="#">Dashboard</a></li>
      <li class="active">HRD</li>
   </ol>
</section>

<section class="content">
   <div class="callout callout-info">
      <h4>Selamat datang!</h4>
      <p>Aplikasi portal HRD PT Bina Sarana Sukses</p>
   </div>
</section>
<script type="text/javascript">
   $(document).ready(function(){
      $("#dashboard").addClass("active");
   });
</script>