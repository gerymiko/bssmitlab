<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/dist-portal/css/AdminLTE.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/dist-portal/css/skins/skin-blue-light.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/dist-portal/css/custom.css"/>
<!-- DATATABLE -->
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/bs-datatables/css/dataTables.bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/bs-datatables/css/responsive.dataTables.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/bs-datatables/css/buttons.dataTables.min.css"/>
<!-- FONTS -->
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/font-awesome/css/all.min.css"/>
<!-- PLUGIN -->
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/bs-timepicker/bs-timepicker.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/bs-datepicker/bs-datepicker.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/bs-daterangepicker/daterangepicker.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/bs-wysihtml5/bs-wysihtml5.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/global/sweetalert/sweetalert2.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/select2/dist/css/select2.min.css"/>
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/pace/pace.min.css">
<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/portalz/toastr/toastr.min.css">
<!-- JQUERY -->
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/portalz/jquery/dist/jquery-3.4.1.min.js"></script>
