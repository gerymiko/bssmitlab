<section class="content-header" id="header-content">
   <h1>Seluruh <b>Pelamar</b><small>Web</small></h1>
   <ol class="breadcrumb">
      	<li><a href="#">Rekrutmen</a></li>
      	<li><a href="#">Web</a></li>
      	<li class="active">Daftar Pelamar</li>
   </ol>
</section>
<div id="extra-content" class="hidden"></div>
<section class="content" id="main-content">
	<div class="row mobile">
		<div class="col-md-12">
			<div class="btn-group pull-right">
				<button type="button" class="btn btn-danger" id="hideshow">Filter</button>
				<button class="btn bg-red">
					<i class="fas fa-filter"></i>
				</button>
			</div>
		</div>
	</div>
	<div class="box box-primary desktop" id="content-filter">
		<div class="box-body">
			<form id="form-filter" action="#" class="form-horizontal">					
				<div class="col-md-2">
					<div class="form-group" style="margin-bottom: 0px;">
	                  	<input type="text" class="form-control _CalPhaNum" id="people_fullname" placeholder="Nama Lengkap">
	                </div>
				</div>
				<div class="col-md-2">
	                <div class="form-group" style="margin-bottom: 0px;">
	                  	<input type="text" class="form-control _CalPhaNum" id="domisili" placeholder="Domisili">
	                </div>
	            </div>
				<div class="col-md-3">
	                <div class="form-group" style="margin-bottom: 0px;">
                        <select class="form-control select2" id="KodeJB">
                            <option></option>
                            <?php
                            	foreach ($listjabatan as $row){
                            		echo '<option value="'.$row->KodeJB.'">'.$row->jabatan.' ['.$row->departemen.']</option>';
                            	}
                            ?>
                        </select>
					</div>
	            </div>
				<div class="col-md-2">
	                <div class="form-group" style="margin-bottom: 0px;">
	                  	<select class="form-control hand" id="freshgraduate">
	                  		<option>Pilih Lulusan Baru</option>
	                  		<option value="1">Ya</option>
	                  		<option value="0">Tidak</option>
	                  	</select>
	                </div>
	            </div>
	            <div class="col-md-2">
	            	<div class="form-group" style="margin-bottom: 0px;">
	                  	<select class="form-control hand" id="status_interview">
	                  		<option>Pilih Status Interview</option>
	                  		<option value="1">Sudah dipanggil</option>
	                  		<option value="0">Belum dipanggil</option>
	                  	</select>
	                </div>
	            </div>
	            <div class="col-md-1 text-center desktop">
	            	<div class="form-group" style="margin-bottom: 0px;">
						<button type="button" id="btn-filter" class="btn btn-flat btn-danger"><i class="fas fa-filter"></i></button>
						<button type="button" id="btn-reset" class="btn btn-flat btn-default"><i class="fas fa-sync"></i></button>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="box">
		<div class="box-body slide-content">
			<table id="table_applicant" class="table table-bordered table-hover" style="width:100%">
				<thead class="bg-cgray">
					<tr>
						<th>No</th>
						<th>#</th>
						<th class="text-center">Nama Lengkap</th>
						<th data-tooltip="Lulusan Baru" data-tooltip-location="right">FG <i class="far fa-question-circle"></i></th>
						<th>Usia</th>
						<th>JK</th>
						<th class="text-center">Posisi</th>
						<th class="text-center">Domisili</th>
						<th>Tgl Lamar</th>
						<th>Status</th>
						<th><i class="fas fa-cog"></i></th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</section>

<div class="modal" id="modal-sms-kspm">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title">Kirim SMS <b>Interview KSPM</b></h4>
			</div>
			<form id="form-sms-kspm" action="#" method="post">
				<input type="hidden" name="people_id" id="people_id">
				<input type="hidden" name="pelamar_id" id="pelamar_id">
				<div class="modal-body">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Nama Pelamar</label>
								<input type="text" id="people_fullname" class="form-control" readonly>
							</div>
							<div class="form-group">
		                       	<label class="control-label">Tanggal</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-calendar-alt"></i>
		                          	</div>
		                          	<input type="text" class="form-control datepicker required pull-right" name="interview_date" maxlength="10" placeholder="dd-mm-yyyy"/>
		                       	</div>
		                    </div>
		                    <div class="form-group">
								<label class="control-label">PIC</label>
		                        <select class="form-control select2" id="pic_kspm">
		                            <option></option>
		                            <?php
		                            	foreach ($listpic as $row){
		                            		echo '<option value="'.$row->pic_id.'">'.$row->pic_name.'</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Lokasi</label>
		                        <select class="form-control select2" id="location">
		                            <option></option>
		                            <?php
		                            	foreach ($listcity as $row){
		                            		echo '<option value="'.$row->city_id.'">'.$row->city_name.' ['.$row->province_name.']</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
							<div class="form-group">
		                       	<label class="control-label">Waktu</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-clock"></i>
		                          	</div>
		                          	<input type="text" class="form-control timepicker required pull-right" name="interview_time" maxlength="8" placeholder="hh-mm AM/PM"/>
		                       	</div>
		                    </div>
						</div>	
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-default btn-sm" data-dismiss="modal" >Batal</button>
					<button class="btn btn-danger btn-sm" id="btn_sms_kspm" >Kirim SMS</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="modal" id="modal-sms-teknis">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title">Kirim SMS <b>Interview Teknis</b></h4>
			</div>
			<form id="form-sms-teknis" action="#" method="post">
				<input type="hidden" name="people_id" id="people_id">
				<input type="hidden" name="pelamar_id" id="pelamar_id">
				<div class="modal-body">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Nama Pelamar</label>
								<input type="text" id="people_fullname" class="form-control" readonly>
							</div>
							<div class="form-group">
		                       	<label class="control-label">Tanggal</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-calendar-alt"></i>
		                          	</div>
		                          	<input type="text" class="form-control datepicker required pull-right" name="interview_date" maxlength="10" placeholder="dd-mm-yyyy"/>
		                       	</div>
		                    </div>
		                    <div class="form-group">
								<label class="control-label">PIC</label>
		                        <select class="form-control select2" id="pic_kspm">
		                            <option></option>
		                            <?php
		                            	foreach ($listpic as $row){
		                            		echo '<option value="'.$row->pic_id.'">'.$row->pic_name.'</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Lokasi</label>
		                        <select class="form-control select2" id="location">
		                            <option></option>
		                            <?php
		                            	foreach ($listcity as $row){
		                            		echo '<option value="'.$row->city_id.'">'.$row->city_name.' ['.$row->province_name.']</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
							<div class="form-group">
		                       	<label class="control-label">Waktu</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-clock"></i>
		                          	</div>
		                          	<input type="text" class="form-control timepicker required pull-right" name="interview_time" maxlength="8" placeholder="hh-mm AM/PM"/>
		                       	</div>
		                    </div>
						</div>	
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-default btn-sm" data-dismiss="modal" >Batal</button>
					<button class="btn btn-danger btn-sm" id="btn_sms_teknis" >Kirim SMS</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="modal" id="modal-sms-teori">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title">Kirim SMS <b>Tes Teori</b></h4>
			</div>
			<form id="form-sms-teori" action="#" method="post">
				<input type="hidden" name="people_id" id="people_id">
				<input type="hidden" name="pelamar_id" id="pelamar_id">
				<div class="modal-body">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Nama Pelamar</label>
								<input type="text" id="people_fullname" class="form-control" readonly>
							</div>
							<div class="form-group">
		                       	<label class="control-label">Tanggal</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-calendar-alt"></i>
		                          	</div>
		                          	<input type="text" class="form-control datepicker required pull-right" name="interview_date" maxlength="10" placeholder="dd-mm-yyyy"/>
		                       	</div>
		                    </div>
		                    <div class="form-group">
								<label class="control-label">PIC</label>
		                        <select class="form-control select2" id="pic_kspm">
		                            <option></option>
		                            <?php
		                            	foreach ($listpic as $row){
		                            		echo '<option value="'.$row->pic_id.'">'.$row->pic_name.'</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Lokasi</label>
		                        <select class="form-control select2" id="location">
		                            <option></option>
		                            <?php
		                            	foreach ($listcity as $row){
		                            		echo '<option value="'.$row->city_id.'">'.$row->city_name.' ['.$row->province_name.']</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
							<div class="form-group">
		                       	<label class="control-label">Waktu</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-clock"></i>
		                          	</div>
		                          	<input type="text" class="form-control timepicker required pull-right" name="interview_time" maxlength="8" placeholder="hh-mm AM/PM"/>
		                       	</div>
		                    </div>
						</div>	
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-default btn-sm" data-dismiss="modal" >Batal</button>
					<button class="btn btn-danger btn-sm" id="btn_sms_teori">Kirim SMS</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="modal" id="modal-sms-praktek">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title">Kirim SMS <b>Tes Praktek</b></h4>
			</div>
			<form id="form-sms-praktek" action="#" method="post">
				<input type="hidden" name="people_id" id="people_id">
				<input type="hidden" name="pelamar_id" id="pelamar_id">
				<div class="modal-body">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Nama Pelamar</label>
								<input type="text" id="people_fullname" class="form-control" readonly>
							</div>
							<div class="form-group">
		                       	<label class="control-label">Tanggal</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-calendar-alt"></i>
		                          	</div>
		                          	<input type="text" class="form-control datepicker required pull-right" name="interview_date" maxlength="10" placeholder="dd-mm-yyyy"/>
		                       	</div>
		                    </div>
		                    <div class="form-group">
								<label class="control-label">PIC</label>
		                        <select class="form-control select2" id="pic_kspm">
		                            <option></option>
		                            <?php
		                            	foreach ($listpic as $row){
		                            		echo '<option value="'.$row->pic_id.'">'.$row->pic_name.'</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Lokasi</label>
		                        <select class="form-control select2" id="location">
		                            <option></option>
		                            <?php
		                            	foreach ($listcity as $row){
		                            		echo '<option value="'.$row->city_id.'">'.$row->city_name.' ['.$row->province_name.']</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
							<div class="form-group">
		                       	<label class="control-label">Waktu</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-clock"></i>
		                          	</div>
		                          	<input type="text" class="form-control timepicker required pull-right" name="interview_time" maxlength="8" placeholder="hh-mm AM/PM"/>
		                       	</div>
		                    </div>
						</div>	
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-default btn-sm" data-dismiss="modal" >Batal</button>
					<button class="btn btn-danger btn-sm" id="btn_sms_praktek">Kirim SMS</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="modal" id="modal-sms-mcu">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title">Kirim SMS <b>Tes MCU</b></h4>
			</div>
			<form id="form-sms-mcu" action="#" method="post">
				<input type="hidden" name="people_id" id="people_id">
				<input type="hidden" name="pelamar_id" id="pelamar_id">
				<div class="modal-body">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Nama Pelamar</label>
								<input type="text" id="people_fullname" class="form-control" readonly>
							</div>
							<div class="form-group">
		                       	<label class="control-label">Tanggal</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-calendar-alt"></i>
		                          	</div>
		                          	<input type="text" class="form-control datepicker required pull-right" name="interview_date" maxlength="10" placeholder="dd-mm-yyyy"/>
		                       	</div>
		                    </div>
		                    <div class="form-group">
								<label class="control-label">PIC</label>
		                        <select class="form-control select2" id="pic_kspm">
		                            <option></option>
		                            <?php
		                            	foreach ($listpic as $row){
		                            		echo '<option value="'.$row->pic_id.'">'.$row->pic_name.'</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label">Lokasi</label>
		                        <select class="form-control select2" id="location">
		                            <option></option>
		                            <?php
		                            	foreach ($listcity as $row){
		                            		echo '<option value="'.$row->city_id.'">'.$row->city_name.' ['.$row->province_name.']</option>';
		                            	}
		                            ?>
		                        </select>
							</div>
							<div style="padding: 17px;"></div>
							<div class="form-group">
		                       	<label class="control-label">Waktu</label>
		                       	<div class="input-group date">
		                          	<div class="input-group-addon">
		                             	<i class="far fa-clock"></i>
		                          	</div>
		                          	<input type="text" class="form-control timepicker required pull-right" name="interview_time" maxlength="8" placeholder="hh-mm AM/PM"/>
		                       	</div>
		                    </div>
						</div>	
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-default btn-sm" data-dismiss="modal" >Batal</button>
					<button class="btn btn-danger btn-sm" id="btn_sms_mcu">Kirim SMS</button>
				</div>
			</form>
		</div>
	</div>
</div>

<style type="text/css">.form-group .select2-container{ margin-bottom:0px !important; }</style>
<script type="text/javascript">
	function format ( d ){
		return '<table cellpadding="0" cellspacing="0" style="padding-left:0px;" class="table table-bordered no-margin">'+
		'<tr>'+
			'<td>KSPM & HRD</td>'+
			'<td>'+d.kspm_status+'</td>'+
			'<td>'+d.kspm+'</td>'+
		'</tr>'+
		'<tr>'+
			'<td>Teknis</td>'+
			'<td>'+d.teknis_status+'</td>'+
			'<td>'+d.teknis+'</td>'+
		'</tr>'+
		'<tr>'+
			'<td>Tes Teori</td>'+
			'<td>'+d.teori_status+'</td>'+
			'<td>'+d.teori+'</td>'+
		'</tr>'+
		'<tr>'+
			'<td>Tes Praktek</td>'+
			'<td>'+d.praktek_status+'</td>'+
			'<td>'+d.praktek+'</td>'+
		'</tr>'+
		'<tr>'+
			'<td>Tes MCU</td>'+
			'<td>'+d.mcu_status+'</td>'+
			'<td>'+d.mcu+'</td>'+
		'</tr>'+
		'</table>';
    }
	$(document).ready(function(){
		$("#recruit, #recruit-applicant, #recruit-treeview").addClass("active");
		$('._CalPhaNum').alphanum({ allowNumeric: false, allow: '.-,' });
		$('._CnUmB').numeric({allowThouSep: true,	allowDecSep: false, allowPlus: false, allowMinus: false });
		$('.datepicker').datepicker({ autoclose: true,format:"dd-mm-yyyy",todayHighlight:true,daysOfWeekHighlighted:"0",todayBtn:"linked" });
		$('.timepicker').timepicker({ showInputs: false });

		var table = $('#table_applicant').DataTable({
			"processing": true,
			"serverSide": true,
			"stateSave": true,
			"order": [],
			"dom": 'Bfrtip',
	        "buttons": [ 'pageLength' ],
	        "lengthMenu": [
	        	[10, 25, 50, 100], 
	        	['10 Baris', '25 Baris', '50 Baris', '100 Baris']
	        ],
			"responsive": {
		        details: {
		            renderer: function ( api, rowIdx, columns ) {
		                var data = $.map( columns, function ( col, i ) {
		                    return col.hidden ?
		                        '<tr data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
		                            '<td>'+col.title+':'+'</td> '+
		                            '<td>'+col.data+'</td>'+
		                        '</tr>' :
		                        '';
		                } ).join('');
		                return data ?
		                    $('<table/>').append( data ) :
		                    false;
		            }
		        }
		    },
			"ajax": {
				"url": '<?=site_url()?>crecruit/web/applicant/sysapplicant/table_applicant',
				"type": 'POST',
				data : function(data){
					data.people_fullname = $('#people_fullname').val();
					data.fullname        = $('#fullname').val();
					data.KodeJB          = $('#KodeJB').val();
					data.domisili        = $('#domisili').val();
					data.freshgraduate   = $('#freshgraduate').val();
	            },
				error: function(data){
					swal({
				        title: "",
				        html: '<i class="fas fa-exclamation-circle f40 margin10 text-orange"></i><br>Gagal menarik data. Klik OK untuk menarik data kembali.',
				        type: "",
				        confirmButtonText: 'Okay',
				    }).then(function(){ table.ajax.reload(); });
				},
			},
			"language": { 
	   			"processing": '<div class="load-bar"><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>',
	   		},
			"columns": [
				{ "data": "no", "className": "text-center", "searchable": false, "orderable": false },
				{ "data": "sms", "className": "text-center", "searchable": false, "orderable": false },
				{ "data": "name", "className": "text-left", "orderable": false },
				{ "data": "fg", "className": "text-center", "searchable": false, "orderable": false },
				{ "data": "age", "className": "text-center", "orderable": false },
				{ "data": "gender", "className": "text-center", "searchable": false, "orderable": false },
				{ "data": "position", "className": "text-left", "orderable": false },
				{ "data": "domisili", "className": "text-left", "orderable": false },
				{ "data": "date", "className": "text-center" },
				{ "data": "status", "className": "text-center", "orderable": false },
				{ "data": "action", "className": "text-center", "orderable": false },
			]
		});
		$('#btn-filter').click(function(){ 
			table.ajax.reload();
		});
		$('#btn-reset').click(function(){ 
			$('#form-filter')[0].reset();
			$('#KodeJB').val(null).trigger('change');
			table.ajax.reload();  
		});
		$('#hideshow').on('click', function(event) {        
	        $('#content-filter').toggle('show');
	    });
		$('#table_applicant tbody').on('click', 'a.details-control', function () {
			var tr  = $(this).closest('tr'),
				row = table.row( tr );
			if ( row.child.isShown() ) {
				row.child.hide();
				tr.removeClass('shown');
			} else {
				row.child( format(row.data()) ).show();
				tr.addClass('shown');
			}
		});

		$('#modal-sms-kspm').on('show.bs.modal', function (event) {
			if (event.namespace == 'bs.modal') {
				var button = $(event.relatedTarget)
				var pid    = button.data('pid')
				var plid    = button.data('plid')
				var name    = button.data('name')
				var modal  = $(this)
				modal.find('#people_id').val(pid)
				modal.find('#pelamar_id').val(plid)
				modal.find('#people_fullname').val(name)
			}
		});

		$('#modal-sms-teknis').on('show.bs.modal', function (event) {
			if (event.namespace == 'bs.modal') {
				var button = $(event.relatedTarget)
				var pid    = button.data('pid')
				var plid    = button.data('plid')
				var name    = button.data('name')
				var modal  = $(this)
				modal.find('#people_id').val(pid)
				modal.find('#pelamar_id').val(plid)
				modal.find('#people_fullname').val(name)
			}
		});

		$('#modal-sms-teori').on('show.bs.modal', function (event) {
			if (event.namespace == 'bs.modal') {
				var button = $(event.relatedTarget)
				var pid    = button.data('pid')
				var plid    = button.data('plid')
				var name    = button.data('name')
				var modal  = $(this)
				modal.find('#people_id').val(pid)
				modal.find('#pelamar_id').val(plid)
				modal.find('#people_fullname').val(name)
			}
		});

		$('#modal-sms-praktek').on('show.bs.modal', function (event) {
			if (event.namespace == 'bs.modal') {
				var button = $(event.relatedTarget)
				var pid    = button.data('pid')
				var plid    = button.data('plid')
				var name    = button.data('name')
				var modal  = $(this)
				modal.find('#people_id').val(pid)
				modal.find('#pelamar_id').val(plid)
				modal.find('#people_fullname').val(name)
			}
		});

		$('#modal-sms-mcu').on('show.bs.modal', function (event) {
			if (event.namespace == 'bs.modal') {
				var button = $(event.relatedTarget)
				var pid    = button.data('pid')
				var plid    = button.data('plid')
				var name    = button.data('name')
				var modal  = $(this)
				modal.find('#people_id').val(pid)
				modal.find('#pelamar_id').val(plid)
				modal.find('#people_fullname').val(name)
			}
		});
	});

	function detailApplicant(id){
		$("#main-content, #header-content").addClass("hidden");
		$("#extra-content").removeClass("hidden");
		$("#extra-content").load("<?=site_url()?>crecruit/web/applicant/sysdetail/detail_applicant/"+id);
	}
</script>
