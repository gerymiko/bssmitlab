<section class="sidebar">
	<ul class="sidebar-menu" data-widget="tree">
		<li class="bg-gray">
			<a href="<?=site_url();?>cpanel/syspanel">
				<i class="fas fa-dot-circle text-red"></i> <span> Dashboard</span>
			</a>
		</li>
		<li class="treeview active menu-open">
			<a href="#">
				<i class="far fa-dot-circle text-blue"></i> <span> Permintaan Tiket</span>
				<span class="pull-right-container">
					<i class="fas fa-angle-left pull-right"></i>
				</span>
			</a>
			<ul class="treeview-menu">
				<li><a href="<?=site_url();?>csubvendor/sysubvendor">- <em>Pesan Tiket</em></a></li>
				<li><a href="<?=site_url();?>coptional/sysoptional/ticket_optional">- <em>Opsi Tiket</em></a></li>
				<li><a href="<?=site_url();?>capproved/sysapproved/ticket_approved">- <em>Tiket Disetujui</em></a></li>
				<li><a href="<?=site_url();?>cordered/sysordered/ticket_ordered">- <em>Tiket Terpesan</em></a></li>
			</ul>
		</li>
		<li>
			<a href="">
				<i class="far fa-dot-circle text-blue"></i> <span> Invoice</span>
			</a>
		</li>
		<li>
			<a href="#">
				<i class="far fa-dot-circle text-blue"></i> <span> Hak Akses</span>
			</a>
		</li>
	</ul>
</section>