<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/Ionicons/css/ionicons.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/select2/dist/css/select2.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/timepicker/bootstrap-timepicker.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/iCheck/minimal/_all.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/dist/css/AdminLTE.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/dist/css/skins/skin-purple-light.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/dist/css/skins/skin-yellow-light.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/dist/css/skins/skin-red-light.min.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/rekrutmen/css/animated.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/dist/css/custom.css">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/global/sweetalert/sweetalert2.min.css" type="text/css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/font-awesome/css/all.min.css" />
<link rel="stylesheet" href="<?=siteURL();?>bssmitlab/_assets/tiket/pace/pace.min.css">
<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/tiket/jquery/dist/jquery.min.js"></script>
