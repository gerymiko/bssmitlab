<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/fastclick/lib/fastclick.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/dist/js/adminlte.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- PLUGIN EXTRA -->
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/select2/dist/js/select2.full.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/timepicker/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/iCheck/icheck.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/datatables.net-bs/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/global/sweetalert/sweetalert2.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/global/alphanum/jquery.alphanum.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/global/jquery-validation/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/global/jquery-validation/dist/localization/messages_id.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/font-awesome/js/all.min.js"></script>
<script type="text/javascript" src="<?=siteURL();?>bssmitlab/_assets/tiket/pace/pace.min.js"></script>