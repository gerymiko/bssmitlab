<section class="content-header">
      <h1>DASH<b>BOARD</b>
      	<small><em>Bina Sarana Sukses System</em></small>
      </h1>
</section>
<section class="content">
	<div class="row">
		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-navy"><i class="fa fa-ticket-alt"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Total <br>Permintaan Tiket</span>
					<span class="info-box-number">20</span>
				</div>
			</div>
		</div>
		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-navy"><i class="fa fa-ticket-alt"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Permintaan Tiket <br>BELUM PROSES</span>
					<span class="info-box-number">10</span>
				</div>
			</div>
		</div>
		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-navy"><i class="fa fa-ticket-alt"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Permintaan Tiket <br>SUDAH PROSES</span>
					<span class="info-box-number">10</span>
				</div>
			</div>
		</div>
	</div>
</section>