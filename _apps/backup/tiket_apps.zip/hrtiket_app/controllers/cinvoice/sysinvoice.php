<?php defined('BASEPATH') OR exit('No direct script access allowed');

    class Sysinvoice extends CI_Controller {

        function __construct() {
            parent::__construct();
            if ($this->session->userdata('users_id') == null || $this->session->userdata('tipeapp') != 'HR_TIKET') {
                redirect('syslogin');
            }
            $this->load->model(['mglobal/mod_hr_global']);
        }

        public function index(){
        	$data = array(
                'header'  => 'pages/ext/header',
                'footer'  => 'pages/ext/footer',
                'sidebar' => 'pages/psidebar/vsidebar',
                'content' => 'pages/pinvoice/vinvoice'
        	);
        	$this->load->view('pages/pindex/tindex', $data);
        }

    }
?>