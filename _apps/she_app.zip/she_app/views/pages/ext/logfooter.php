	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/she/js/getmdl-select.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/she/js/material.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/she/js/scroll/scroll.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/select2/select2.full.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/jquery-validation/dist/jquery.validate.min.js"></script>