    <link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/she/css/lib/custom.css">
    <link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/she/css/application.min.css">
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/global/select2/select2.min.css"/>
    <link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/global/toastr/toastr.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/she/vendor/bootstrap/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?=siteURL()?>bssmitlab/_assets/she/vendor/bs-datatables/css/dataTables.bootstrap4.min.css"/>
	<?php if(count($css_script) !== 0){ for ($i=0; $i < count($css_script); $i++) { echo $css_script[$i];}}?>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/jquery/jquery-3.4.1.min.js"></script>
