	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/she/js/material.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/she/js/layout/layout.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/she/js/scroll/scroll.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/alphanum/jquery.alphanum.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/toastr/toastr.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/global/jquery-validation/dist/jquery.validate.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/she/vendor/bootstrap/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/she/vendor/bs-datatables/js/jquery.dataTablesx.min.js"></script>
	<script type="text/javascript" src="<?=siteURL()?>bssmitlab/_assets/she/vendor/bs-datatables/js/dataTables.bootstrap4.min.js"></script>
	<?php if(count($js_script) !== 0){ for ($i=0; $i < count($js_script); $i++){ echo $js_script[$i];}}?>
	




