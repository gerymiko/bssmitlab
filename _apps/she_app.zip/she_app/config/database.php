<?php defined('BASEPATH') OR exit('No direct script access allowed');

$active_group = 'AGM';
$query_builder = TRUE;

$db['AGM'] = array(
	'dsn'	=> '',
	'hostname' => 'agm.binasaranasukses.com',
	'username' => 'admin_erp',
	'password' => '4dminb55',
	'database' => 'SHE',
	'dbdriver' => 'sqlsrv',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => FALSE,
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt'  => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);

$active_group = 'MSJ';
$query_builder = TRUE;

$db['MSJ'] = array(
	'dsn'	=> '',
	'hostname' => 'msj.binasaranasukses.com',
	'username' => 'admin_erp',
	'password' => '4dminb55',
	'database' => 'SHE',
	'dbdriver' => 'sqlsrv',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => FALSE,
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt'  => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);

$active_group = 'MAS';
$query_builder = TRUE;

$db['MAS'] = array(
	'dsn'	=> '',
	'hostname' => 'msj.binasaranasukses.com',
	'username' => 'admin_erp',
	'password' => '4dminb55',
	'database' => 'SHE',
	'dbdriver' => 'sqlsrv',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => FALSE,
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt'  => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);

$active_group = 'KUP';
$query_builder = TRUE;

$db['KUP'] = array(
	'dsn'	=> '',
	'hostname' => 'msj.binasaranasukses.com',
	'username' => 'admin_erp',
	'password' => '4dminb55',
	'database' => 'SHE',
	'dbdriver' => 'sqlsrv',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => FALSE,
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt'  => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);